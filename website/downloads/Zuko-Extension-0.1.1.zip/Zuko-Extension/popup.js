// src/shared/mascot.ts
var NS = "http://www.w3.org/2000/svg";
var uid = 0;
function el(doc, tag, attrs = {}, kids = []) {
  const e = doc.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
  for (const c of kids) e.appendChild(c);
  return e;
}
function stop(doc, offset, color) {
  return el(doc, "stop", { offset, "stop-color": color });
}
function mascotSvg(doc) {
  const n = ++uid;
  const head = `zk-head-${n}`;
  const eye = `zk-eye-${n}`;
  const defs = el(doc, "defs", {}, [
    el(doc, "radialGradient", { id: head, cx: "36%", cy: "28%", r: "78%" }, [
      stop(doc, 0, "#FFFFFF"),
      stop(doc, 0.3, "#F7F3EE"),
      stop(doc, 0.8, "#E8D5C4"),
      stop(doc, 1, "#CBAE96")
    ]),
    el(doc, "radialGradient", { id: eye, cx: "50%", cy: "55%", r: "60%" }, [
      stop(doc, 0, "#FFF3CF"),
      stop(doc, 0.45, "#FFB347"),
      stop(doc, 1, "#F28A1E")
    ])
  ]);
  const dark = "#2B1D1A";
  const outline = "#1E1310";
  const almond = (cx, mirror) => el(doc, "path", {
    d: "M-5.2 1.6 C-3 -4.2 2.6 -5.8 5.4 -3 C5.2 2.8 1.2 6 -2 5.6 C-3.8 5.2 -5 3.6 -5.2 1.6Z",
    transform: `translate(${cx} 38) scale(${mirror} 1)`,
    fill: `url(#${eye})`,
    stroke: "#B5400E",
    "stroke-width": 0.8
  });
  const svg = el(doc, "svg", { viewBox: "0 0 64 64", width: "100%", height: "100%", "aria-hidden": "true", focusable: "false" }, [
    defs,
    // Ponytail swoosh and topknot behind the head.
    el(doc, "path", { d: "M33 13 C41 1 58 5 60 26 C60 33 56 36 55 40 C54 32 52 20 40 17Z", fill: dark, stroke: outline, "stroke-width": 1, "stroke-linejoin": "round" }),
    el(doc, "ellipse", { cx: 32, cy: 10, rx: 6.2, ry: 5, fill: dark, stroke: outline, "stroke-width": 1 }),
    // Maroon tunic with a gold collar.
    el(doc, "path", { d: "M14 64 C15 54 24 52 32 56 C40 52 49 54 50 64Z", fill: "#6E1F18", stroke: outline, "stroke-width": 1, "stroke-linejoin": "round" }),
    el(doc, "path", { d: "M22 54 C27 58 37 58 42 54", fill: "none", stroke: "#E0A030", "stroke-width": 2, "stroke-linecap": "round" }),
    // Head.
    el(doc, "circle", { cx: 32, cy: 35, r: 22, fill: `url(#${head})`, stroke: outline, "stroke-width": 1.6 }),
    // Flame scar round the viewer's right eye.
    el(doc, "path", { d: "M36 40 C33 32 36 26 40 27 C41 25 43 26 43.5 24.5 C46 27 52 29 53 36 C54 44 48 48 42 47 C38 46.5 36.5 43.5 36 40Z", fill: "#B33A2E", opacity: 0.45 }),
    // Eyes.
    almond(23, -1),
    almond(41, 1),
    el(doc, "ellipse", { cx: 22.4, cy: 38, rx: 1.3, ry: 1.7, fill: "#FFFBEA", opacity: 0.85 }),
    el(doc, "ellipse", { cx: 40.4, cy: 38, rx: 1.3, ry: 1.7, fill: "#FFFBEA", opacity: 0.85 }),
    // Highlight.
    el(doc, "ellipse", { cx: 22, cy: 22.5, rx: 6, ry: 3.2, transform: "rotate(-35 22 22.5)", fill: "#FFFFFF", opacity: 0.8 }),
    // Hair-tie.
    el(doc, "rect", { x: 28.4, y: 11.6, width: 7.2, height: 4.6, rx: 1.4, fill: "#B33A2E", stroke: outline, "stroke-width": 0.8 }),
    el(doc, "rect", { x: 28.4, y: 12.8, width: 7.2, height: 0.9, fill: "#E0A030" })
  ]);
  return svg;
}

// src/shared/sites.ts
var SITE_IDS = ["chatgpt", "claude", "deepseek"];
var SITE_LABELS = {
  chatgpt: "ChatGPT",
  claude: "Claude",
  deepseek: "DeepSeek"
};

// src/popup/popup.ts
var SITE_HOST = {
  chatgpt: "chatgpt.com, chat.openai.com",
  claude: "claude.ai",
  deepseek: "chat.deepseek.com"
};
var $ = (id) => document.getElementById(id);
async function ask(msg) {
  try {
    return await chrome.runtime.sendMessage(msg);
  } catch {
    return null;
  }
}
function setStatus(dot, value, level, text) {
  $(dot).className = `dot ${level}`;
  $(value).textContent = text;
}
function renderSites(prefs) {
  const host = $("sites");
  if (host.childElementCount === SITE_IDS.length) {
    for (const id of SITE_IDS) document.getElementById(`sw-${id}`).checked = prefs.sites[id] !== false;
    return;
  }
  for (const id of SITE_IDS) {
    const label = document.createElement("label");
    label.className = "site";
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = SITE_LABELS[id];
    const small = document.createElement("span");
    small.className = "host";
    small.textContent = SITE_HOST[id];
    name.appendChild(small);
    const sw = document.createElement("span");
    sw.className = "switch";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.id = `sw-${id}`;
    input.checked = prefs.sites[id] !== false;
    input.setAttribute("aria-label", `Protect ${SITE_LABELS[id]}`);
    input.addEventListener("change", () => void ask({ type: "setSite", site: id, enabled: input.checked }));
    const track = document.createElement("span");
    track.className = "track";
    const thumb = document.createElement("span");
    thumb.className = "thumb";
    sw.append(input, track, thumb);
    label.append(name, sw);
    host.appendChild(label);
  }
}
function render(s) {
  $("version").textContent = `v${s.version} · privacy guard for AI chats`;
  if (s.engine) setStatus("dot-engine", "val-engine", "ok", "loaded");
  else setStatus("dot-engine", "val-engine", "bad", "not loaded");
  const relink = $("btn-relink");
  if (s.linked) {
    setStatus("dot-desktop", "val-desktop", "ok", s.appVersion ? `linked (v${s.appVersion})` : "linked");
    relink.hidden = true;
  } else {
    setStatus("dot-desktop", "val-desktop", "warn", "not linked");
    relink.hidden = false;
  }
  const ai = s.localAi;
  if (!s.linked || !ai || !ai.enabled) {
    $("dot-ai").className = "dot";
    $("val-ai").textContent = "off";
  } else if (!ai.reachable) setStatus("dot-ai", "val-ai", "warn", "unreachable");
  else setStatus("dot-ai", "val-ai", "ok", `on (${ai.model})`);
  const hint = $("hint");
  if (!s.engine) {
    hint.hidden = false;
    hint.textContent = `The privacy engine is missing, so Zuko can only block obvious secrets. ${s.engineError ?? ""} Build zuko_core.wasm and rebuild the extension (see the README).`.trim();
  } else if (!s.linked) {
    hint.hidden = false;
    const unregistered = /not found/i.test(s.linkError ?? "");
    hint.textContent = unregistered ? "Zuko works on its own. To share one vault with Claude Code, start the Zuko desktop app once (it registers its bridge for this browser), then reload this extension." : "Zuko works on its own. Link the desktop app to share one vault with Claude Code" + (s.linkError ? ` (${s.linkError.replace(/\.$/, "")}).` : ". It connects by itself within half a minute of starting.");
  } else {
    hint.hidden = true;
  }
  renderSites(s.prefs);
  $("n-masked").textContent = String(s.total.masked);
  $("n-blocked").textContent = String(s.total.blocked);
  $("n-uploads").textContent = String(s.total.uploads);
  $("n-restored").textContent = String(s.total.restored);
  $("n-vault").textContent = String(s.vaultSize);
}
async function refresh() {
  const s = await ask({ type: "status" });
  if (s?.ok) render(s);
  else {
    setStatus("dot-engine", "val-engine", "bad", "no answer");
    setStatus("dot-desktop", "val-desktop", "warn", "unknown");
  }
}
$("btn-relink").addEventListener("click", async () => {
  $("val-desktop").textContent = "connecting...";
  await ask({ type: "relink" });
  await refresh();
});
$("btn-clear").addEventListener("click", async () => {
  if (!confirm("Forget every value Zuko masked in this browser session? Placeholders already in your chats will stop being restored.")) return;
  await ask({ type: "clearVault" });
  await refresh();
});
$("mascot").appendChild(mascotSvg(document));
void refresh();
setInterval(() => void refresh(), 2e3);
