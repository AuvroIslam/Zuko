"use strict";
(() => {
  // src/content/bridge.ts
  var PORT_TAG = "port";
  var READY_EVENT = "zuko:main-ready";
  var ContentBridge = class {
    win;
    handlers;
    port = null;
    offered = null;
    state = { type: "state", enabled: true, vaultSize: 0, engine: true };
    constructor(win, handlers) {
      this.win = win;
      this.handlers = handlers;
    }
    /** Offers a port to the page's net guard (whichever script loaded first). */
    start() {
      this.win.addEventListener(READY_EVENT, () => {
        if (!this.port) this.offer();
      });
      this.offer();
    }
    pushState(state) {
      this.state = { type: "state", ...state };
      this.port?.postMessage(this.state);
    }
    offer() {
      this.offered?.close();
      const ch = new this.win.MessageChannel();
      ch.port1.onmessage = (e) => this.onMessage(ch.port1, e);
      this.offered = ch.port1;
      this.win.postMessage({ __zuko: PORT_TAG }, "*", [ch.port2]);
    }
    onMessage(from, e) {
      const m = e.data;
      if (!m || typeof m !== "object") return;
      if (!this.port) {
        if (m.type !== "hello") return;
        this.port = from;
        this.offered = null;
        this.port.postMessage(this.state);
        return;
      }
      if (from !== this.port) return;
      const req = m;
      switch (req.type) {
        case "notify":
          if (typeof req.text === "string") this.handlers.notify(req.level === "error" || req.level === "warn" ? req.level : "info", req.text.slice(0, 600));
          return;
        case "event":
          this.handlers.event(req.kind, Number(req.count) || 0, Array.isArray(req.keys) ? req.keys.map(String) : []);
          return;
        case "maskMany":
        case "tripwire":
        case "clipboard": {
          const id = req.id;
          this.handlers.request(req).then(
            (r) => ({ id, ok: true, ...r }),
            (err) => ({ id, ok: false, error: err instanceof Error ? err.message : String(err) })
          ).then((reply) => this.port?.postMessage(reply));
          return;
        }
      }
    }
  };

  // src/content/sites.ts
  var GENERIC = {
    composer: ["textarea", '[contenteditable="true"][role="textbox"]', '[contenteditable="true"]', '[contenteditable="plaintext-only"]'],
    messages: ["[data-message-author-role]", "article", '[role="article"]'],
    userMessages: ['[data-message-author-role="user"]']
  };
  var SELECTORS = {
    chatgpt: {
      composer: [
        "#prompt-textarea",
        "form div.ProseMirror[contenteditable=true]",
        "div.ProseMirror[data-composer-markdown]",
        "[data-mobile-composer-prompt]",
        "form textarea[name=prompt]"
      ],
      messages: [
        "[data-message-author-role]",
        "li[data-message-role]",
        "[data-turn-key]",
        '[data-testid^="conversation-turn"]',
        "h4[data-conversation-role]"
      ],
      userMessages: ['[data-message-author-role="user"]', 'li[data-message-role="user"]', 'h4[data-conversation-role="user"]']
    },
    claude: {
      composer: ['fieldset [contenteditable="true"]', '[contenteditable="true"][role="textbox"]', ".ProseMirror[contenteditable=true]"],
      messages: ['[data-testid="user-message"]', ".font-claude-message", ".font-claude-response", "[data-is-streaming]"],
      userMessages: ['[data-testid="user-message"]']
    },
    deepseek: {
      composer: ["textarea#chat-input", ".ds-textarea textarea", "textarea"],
      messages: [".ds-markdown", ".ds-message", '[class*="message"]'],
      userMessages: [".ds-message:not(:has(.ds-markdown))", '[class*="user-message"]']
    }
  };
  function selectorsFor(site2, key) {
    return [...SELECTORS[site2][key], ...GENERIC[key]];
  }
  function safeQuery(root, selector) {
    try {
      return root.querySelector(selector);
    } catch {
      return null;
    }
  }
  function safeQueryAll(root, selector) {
    try {
      return [...root.querySelectorAll(selector)];
    } catch {
      return [];
    }
  }
  function isEditable(el2) {
    if (!el2) return false;
    const tag = el2.tagName;
    if (tag === "TEXTAREA") return true;
    if (tag === "INPUT") return /^(text|search|url|email|tel)?$/.test(el2.type);
    const ce = el2.getAttribute?.("contenteditable");
    return ce === "" || ce === "true" || ce === "plaintext-only";
  }
  function findComposer(doc, site2, from) {
    const sels = selectorsFor(site2, "composer");
    if (from instanceof (doc.defaultView?.Element ?? Element)) {
      const el2 = from;
      for (const s of sels) {
        try {
          const hit = el2.closest(s);
          if (hit && isEditable(hit)) return hit;
        } catch {
        }
      }
      return null;
    }
    for (const s of sels) {
      const el2 = safeQuery(doc, s);
      if (el2 && isEditable(el2)) return el2;
    }
    return null;
  }
  function composerText(el2) {
    if (el2.tagName === "TEXTAREA" || el2.tagName === "INPUT") return el2.value;
    return el2.innerText ?? el2.textContent ?? "";
  }
  function messageContainers(doc, site2, root) {
    const sels = selectorsFor(site2, "messages");
    const found = /* @__PURE__ */ new Set();
    for (const s of sels) for (const el2 of safeQueryAll(root, s)) found.add(el2);
    if (root instanceof (doc.defaultView?.Element ?? Element)) {
      for (const s of sels) {
        try {
          const up = root.closest(s);
          if (up) found.add(up);
        } catch {
        }
      }
    }
    return [...found];
  }
  function rehydrationRoots(doc, site2, dirty) {
    const msgs = messageContainers(doc, site2, dirty);
    if (msgs.length > 0) return msgs;
    const anyMessage = selectorsFor(site2, "messages").some((s) => safeQuery(doc, s) !== null);
    if (anyMessage) return [];
    return [safeQuery(doc, "main") ?? safeQuery(doc, '[role="main"]') ?? doc.body].filter(Boolean);
  }

  // src/content/composer.ts
  var ComposerChip = class {
    doc;
    site;
    overlay;
    scan;
    composer = null;
    timer = null;
    seq = 0;
    enabled = true;
    offlineShown = false;
    constructor(doc, site2, overlay, scan) {
      this.doc = doc;
      this.site = site2;
      this.overlay = overlay;
      this.scan = scan;
    }
    start() {
      const win = this.doc.defaultView;
      this.doc.addEventListener("input", (e) => this.onInput(e), true);
      const reposition = () => this.composer && this.composer.isConnected && this.schedule(60);
      win.addEventListener("resize", reposition, { passive: true });
      win.addEventListener("scroll", reposition, { passive: true, capture: true });
    }
    setEnabled(on) {
      this.enabled = on;
      if (!on) this.overlay.chip(null);
      else this.schedule(0);
    }
    onInput(e) {
      if (!this.enabled) return;
      const c = findComposer(this.doc, this.site, e.target);
      if (!c) return;
      this.composer = c;
      this.schedule(350);
    }
    schedule(ms) {
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => void this.update(), ms);
    }
    async update() {
      this.timer = null;
      const c = this.composer;
      if (!this.enabled || !c || !c.isConnected) {
        this.overlay.chip(null);
        return;
      }
      const text = composerText(c);
      if (text.trim().length < 6 || text.length > 4e5) {
        this.overlay.chip(null);
        return;
      }
      const mine = ++this.seq;
      const r = await this.scan(text);
      if (mine !== this.seq) return;
      const rect = c.getBoundingClientRect();
      if (!r.ok) {
        if (!this.offlineShown) {
          this.offlineShown = true;
          this.overlay.chip("Zuko engine offline: secrets will be blocked", "warn", rect);
        }
        return;
      }
      this.offlineShown = false;
      const n = r.count ?? 0;
      if (n === 0) {
        this.overlay.chip(null);
        return;
      }
      const kinds = [...new Set((r.items ?? []).map((i) => i.label))].slice(0, 5).join(", ");
      this.overlay.chip(`Zuko: ${n} ${n === 1 ? "item" : "items"} will be masked`, "info", rect, kinds);
    }
  };

  // src/shared/placeholders.ts
  var NOTE_PREFIX = "[Zuko privacy note:";
  var KEY_RE = /^([A-Z][A-Z0-9_]*[A-Z0-9])_([1-9]\d*)$|^([A-Z])_([1-9]\d*)$/;
  function parseKey(key) {
    const m = KEY_RE.exec(key);
    if (!m) return null;
    return { kind: m[1] ?? m[3], n: Number(m[2] ?? m[4]) };
  }
  function wrap(key) {
    return `{{${key}}}`;
  }
  function buildNote(keys) {
    const uniq = [...new Set(keys)];
    const shown = uniq.slice(0, 6).map(wrap).join(", ") + (uniq.length > 6 ? ", ..." : "");
    const verb = uniq.length === 1 ? "is a placeholder" : "are placeholders";
    return `${NOTE_PREFIX} ${shown} ${verb} for private values kept on the user's machine. Use ${uniq.length === 1 ? "it" : "them"} verbatim, exactly as written, and never ask for or guess the real values.]`;
  }
  function isComplete(open, close) {
    if (!close) return false;
    if (!open) return true;
    const o = open.trim();
    const c = close.trim();
    return o.length === 2 ? c.length === 2 : c.length === 1;
  }
  var escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  var WORD = /[\p{L}\p{N}_]/u;
  var isWord = (ch) => ch !== void 0 && ch !== "" && WORD.test(ch);
  var VariantMatcher = class {
    keys;
    flatKinds = /* @__PURE__ */ new Map();
    re;
    constructor(keys) {
      this.keys = /* @__PURE__ */ new Set();
      const kinds = /* @__PURE__ */ new Set();
      for (const k of keys) {
        const p = parseKey(k);
        if (!p) continue;
        this.keys.add(k);
        kinds.add(p.kind);
      }
      for (const kind of kinds) {
        const flat = kind.replace(/_/g, "");
        if (!this.flatKinds.has(flat)) this.flatKinds.set(flat, kind);
      }
      if (kinds.size === 0) {
        this.re = null;
        return;
      }
      const kindAlt = [...kinds].sort((a, b) => b.length - a.length).map((k) => k.split("_").map(escapeRe).join("[_ ]?")).join("|");
      this.re = new RegExp(
        `(\\{\\{[ \\t]*|\\[\\[[ \\t]*|\\{[ \\t]*|\\[[ \\t]*)?(${kindAlt})[_ ]?(\\d{1,9})(?!\\d)([ \\t]*\\}\\}|[ \\t]*\\]\\]|[ \\t]*\\}|[ \\t]*\\])?`,
        "gi"
      );
    }
    get size() {
      return this.keys.size;
    }
    has(key) {
      return this.keys.has(key);
    }
    /** Cheap pre-check so most text nodes are skipped without running the regex. */
    mightContain(text) {
      return this.re !== null && /\d/.test(text);
    }
    find(text) {
      const re = this.re;
      if (!re || !text) return [];
      re.lastIndex = 0;
      const out = [];
      let m;
      while ((m = re.exec(text)) !== null) {
        const whole = m[0];
        const open = m[1];
        const kindText = m[2];
        const digits = m[3];
        const close = m[4];
        if (digits.startsWith("0")) continue;
        const kind = this.flatKinds.get(kindText.replace(/[_ ]/g, "").toUpperCase());
        if (!kind) continue;
        const key = `${kind}_${Number(digits)}`;
        if (!this.keys.has(key)) continue;
        const start = m.index;
        const end = start + whole.length;
        if (!open && !close) {
          if (kindText !== kindText.toUpperCase()) continue;
          if (isWord(text[start - 1]) || isWord(text[end])) continue;
        } else {
          if (!open && isWord(text[start - 1])) continue;
          if (!close && isWord(text[end])) continue;
        }
        out.push({ start, end, key, text: whole, complete: isComplete(open, close) });
      }
      return out;
    }
    /** The distinct keys that appear (in any accepted form). */
    keysIn(text) {
      return [...new Set(this.find(text).map((v) => v.key))];
    }
  };
  function replaceVariants(text, matcher, lookup) {
    const matches = matcher.find(text);
    if (matches.length === 0) return { text, ranges: [], count: 0 };
    let out = "";
    let pos = 0;
    const ranges = [];
    for (const v of matches) {
      const value = lookup(v.key);
      if (value === void 0) continue;
      out += text.slice(pos, v.start);
      ranges.push({ start: out.length, end: out.length + value.length, key: v.key });
      out += value;
      pos = v.end;
    }
    out += text.slice(pos);
    return { text: out, ranges, count: ranges.length };
  }

  // src/content/clipboard.ts
  var escapeHtml = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  async function restoreText(text, env, html = false) {
    const matcher = env.matcher();
    if (matcher.size === 0 || !matcher.mightContain(text)) return null;
    const keys = matcher.keysIn(text);
    if (keys.length === 0) return null;
    await env.source.load(keys);
    const esc = html ? escapeHtml : (s) => s;
    const r = replaceVariants(text, matcher, (k) => {
      const v = env.source.value(k);
      return v === void 0 ? void 0 : esc(v);
    });
    return r.count > 0 ? r.text : null;
  }
  async function writeRestoredClipboard(items, env) {
    const out = {};
    let changed = false;
    for (const [type, text] of Object.entries(items)) {
      const restored = await restoreText(text, env, type === "text/html");
      out[type] = restored ?? text;
      if (restored !== null) changed = true;
    }
    if (!changed) return { written: false };
    const nav = env.doc.defaultView?.navigator;
    const win = env.doc.defaultView;
    try {
      if (Object.keys(out).length === 1 && out["text/plain"] !== void 0) {
        await nav.clipboard.writeText(out["text/plain"]);
      } else {
        const data = {};
        for (const [type, text] of Object.entries(out)) data[type] = new win.Blob([text], { type });
        await nav.clipboard.write([new win.ClipboardItem(data)]);
      }
      return { written: true };
    } catch {
      return { written: false };
    }
  }
  function installCopyHandler(env) {
    env.doc.addEventListener(
      "copy",
      (e) => {
        if (!env.enabled()) return;
        const sel = env.doc.getSelection();
        const text = sel?.toString();
        if (!text || !e.clipboardData) return;
        const ElementCtor = env.doc.defaultView?.Element ?? Element;
        const anchor = sel?.anchorNode instanceof ElementCtor ? sel.anchorNode : sel?.anchorNode?.parentElement ?? null;
        for (let p = anchor; p; p = p.parentElement) if (isEditable(p)) return;
        const matcher = env.matcher();
        if (matcher.size === 0 || !matcher.mightContain(text)) return;
        const r = replaceVariants(text, matcher, (k) => env.source.value(k));
        if (r.count === 0) return;
        e.clipboardData.setData("text/plain", r.text);
        e.preventDefault();
      },
      true
    );
  }

  // src/content/rehydrate.ts
  var BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ADDRESS",
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "BODY",
    "DD",
    "DETAILS",
    "DIV",
    "DL",
    "DT",
    "FIELDSET",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "FORM",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "PRE",
    "SECTION",
    "TABLE",
    "TBODY",
    "TD",
    "TH",
    "THEAD",
    "TR",
    "UL"
  ]);
  var SKIP_TAGS = /* @__PURE__ */ new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION", "TEMPLATE", "ZUKO-OVERLAY"]);
  var NOTE_RE = /^\s*\[Zuko privacy note:[^\]]*\]\s*/;
  var SHOW_TEXT = 4;
  var HIGHLIGHT_NAME = "zuko-restored";
  var MASKED_HIGHLIGHT_NAME = "zuko-masked";
  var Rehydrator = class {
    doc;
    win;
    site;
    source;
    onRestored;
    onToggle;
    delayMs;
    settleMs;
    matcher;
    records = /* @__PURE__ */ new WeakMap();
    tracked = /* @__PURE__ */ new Set();
    dirty = /* @__PURE__ */ new Set();
    timer = null;
    /** Blocks whose text ends in a placeholder that may still be growing (streaming). */
    deferred = /* @__PURE__ */ new Set();
    settleTimer = null;
    observer = null;
    highlight = null;
    maskedHighlight = null;
    onTracked;
    revealed = true;
    running = false;
    constructor(opts) {
      this.doc = opts.doc;
      this.win = opts.doc.defaultView;
      this.site = opts.site;
      this.source = opts.source;
      this.onRestored = opts.onRestored;
      this.onToggle = opts.onToggle;
      this.onTracked = opts.onTracked;
      this.delayMs = opts.delayMs ?? 60;
      this.settleMs = opts.settleMs ?? 800;
      this.matcher = new VariantMatcher(this.source.keys());
    }
    get isRevealed() {
      return this.revealed;
    }
    /** The matcher the copy handler shares. */
    get variantMatcher() {
      return this.matcher;
    }
    /** For tests. */
    get highlightedRangeCount() {
      return this.highlight ? this.highlight.size : 0;
    }
    start() {
      if (this.running) return;
      this.running = true;
      this.setupHighlight();
      const body = this.doc.body ?? this.doc.documentElement;
      this.observer = new this.win.MutationObserver((records) => {
        for (const r of records) {
          if (r.type === "characterData") this.dirty.add(r.target);
          else r.addedNodes.forEach((n) => this.dirty.add(n));
        }
        this.schedule();
      });
      this.observer.observe(body, { childList: true, subtree: true, characterData: true });
      this.dirty.add(body);
      this.schedule();
    }
    stop() {
      this.running = false;
      this.observer?.disconnect();
      this.observer = null;
      if (this.timer) clearTimeout(this.timer);
      if (this.settleTimer) clearTimeout(this.settleTimer);
      this.timer = null;
      this.settleTimer = null;
      this.deferred.clear();
      this.revert();
    }
    /** The vault changed: rebuild the matcher and look at everything again. */
    refresh() {
      this.matcher = new VariantMatcher(this.source.keys());
      if (!this.running) return;
      this.dirty.add(this.doc.body ?? this.doc.documentElement);
      this.schedule();
    }
    /** Alt+R: masked text <-> real values. Returns the new state (true = real values shown). */
    toggle() {
      this.revealed = !this.revealed;
      for (const ref of [...this.tracked]) {
        const node = ref.deref();
        const rec = node ? this.records.get(node) : void 0;
        if (!node || !rec || !node.isConnected) {
          this.tracked.delete(ref);
          continue;
        }
        node.nodeValue = this.revealed ? rec.restored : rec.masked;
      }
      if (this.revealed) {
        this.maskedHighlight?.clear();
        this.paintAll();
      } else {
        this.highlight?.clear();
        this.paintMasked();
      }
      this.onToggle?.(this.revealed);
      return this.revealed;
    }
    /** Processes everything pending right now (tests and the first paint). */
    async flushNow(opts = {}) {
      if (this.timer) clearTimeout(this.timer);
      this.timer = null;
      await this.flush();
      if (opts.settle) await this.settle();
    }
    /** Restores placeholders that sat at the very end of text which has since stopped changing. */
    async settle() {
      if (this.settleTimer) clearTimeout(this.settleTimer);
      this.settleTimer = null;
      if (!this.revealed || this.deferred.size === 0) return;
      const blocks = [...this.deferred];
      this.deferred.clear();
      const skipCache = /* @__PURE__ */ new Map();
      let restored = 0;
      const keys = /* @__PURE__ */ new Set();
      const need = /* @__PURE__ */ new Set();
      for (const b of blocks) {
        if (!b.isConnected) continue;
        const r = this.processBlock(b, need, skipCache, true);
        restored += r.count;
        r.keys.forEach((k) => keys.add(k));
      }
      if (need.size > 0) {
        await this.source.load([...need]).catch(() => void 0);
        for (const b of blocks) {
          if (!b.isConnected) continue;
          const r = this.processBlock(b, /* @__PURE__ */ new Set(), skipCache, true);
          restored += r.count;
          r.keys.forEach((k) => keys.add(k));
        }
      }
      if (restored > 0) this.onRestored?.(restored, [...keys]);
    }
    // ---- scheduling -----------------------------------------------------------------------
    schedule() {
      if (this.timer || !this.running) return;
      this.timer = setTimeout(() => {
        this.timer = null;
        void this.flush();
      }, this.delayMs);
    }
    async flush() {
      if (!this.revealed) {
        this.dirty.clear();
        return;
      }
      const dirty = [...this.dirty];
      this.dirty.clear();
      const blocks = /* @__PURE__ */ new Set();
      for (const n of dirty) {
        if (!n.isConnected) continue;
        if (n.nodeType === 3) {
          const parent = n.parentElement;
          if (!parent || rehydrationRoots(this.doc, this.site, parent).length === 0) continue;
          const b = this.blockOf(n);
          if (b) blocks.add(b);
        } else if (n.nodeType === 1) {
          for (const root of rehydrationRoots(this.doc, this.site, n)) this.blocksUnder(root, blocks);
        }
      }
      const skipCache = /* @__PURE__ */ new Map();
      const need = /* @__PURE__ */ new Set();
      const retry = [];
      let restored = 0;
      const keys = /* @__PURE__ */ new Set();
      for (const b of blocks) {
        if (!b.isConnected) continue;
        const r = this.processBlock(b, need, skipCache, false);
        restored += r.count;
        r.keys.forEach((k) => keys.add(k));
        if (r.unresolved) retry.push(b);
        if (r.deferred) this.deferred.add(b);
      }
      if (restored > 0) this.onRestored?.(restored, [...keys]);
      if (this.deferred.size > 0) {
        if (this.settleTimer) clearTimeout(this.settleTimer);
        this.settleTimer = setTimeout(() => void this.settle(), this.settleMs);
      }
      if (need.size > 0) {
        await this.source.load([...need]).catch(() => void 0);
        if (!this.revealed) return;
        let again = 0;
        const more = /* @__PURE__ */ new Set();
        for (const b of retry) {
          if (!b.isConnected) continue;
          const r = this.processBlock(b, /* @__PURE__ */ new Set(), skipCache, false);
          again += r.count;
          if (r.deferred) this.deferred.add(b);
          r.keys.forEach((k) => more.add(k));
        }
        if (again > 0) this.onRestored?.(again, [...more]);
      }
    }
    // ---- finding text ---------------------------------------------------------------------
    blockOf(node) {
      let el2 = node.parentElement;
      while (el2 && !BLOCK_TAGS.has(el2.tagName)) el2 = el2.parentElement;
      return el2;
    }
    skipped(el2, cache) {
      const hit = cache.get(el2);
      if (hit !== void 0) return hit;
      const result = SKIP_TAGS.has(el2.tagName) || isEditable(el2) || (el2.parentElement ? this.skipped(el2.parentElement, cache) : false);
      cache.set(el2, result);
      return result;
    }
    /** Adds the block-level elements that hold text under `root` (and `root` if it is one). */
    blocksUnder(root, out) {
      const walker = this.doc.createTreeWalker(root, SHOW_TEXT);
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        if (!n.nodeValue) continue;
        const b = this.blockOf(n);
        if (b) out.add(b);
      }
    }
    /** Restores every run of text under a block. */
    processBlock(block, need, skipCache, final) {
      const runs = [];
      let current = [];
      let currentBlock = null;
      const walker = this.doc.createTreeWalker(block, SHOW_TEXT);
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const t = n;
        const parent = t.parentElement;
        if (!parent || this.skipped(parent, skipCache)) continue;
        const b = this.blockOf(t);
        if (b !== currentBlock) {
          if (current.length) runs.push(current);
          current = [];
          currentBlock = b;
        }
        current.push(t);
      }
      if (current.length) runs.push(current);
      let count = 0;
      const keys = [];
      let unresolved = false;
      let deferred = false;
      for (const run of runs) {
        const r = this.processRun(run, need, final);
        count += r.count;
        keys.push(...r.keys);
        unresolved ||= r.unresolved;
        deferred ||= r.deferred;
      }
      return { count, keys, unresolved, deferred };
    }
    // ---- restoring ------------------------------------------------------------------------
    processRun(nodes, need, final) {
      const texts = nodes.map((n) => n.nodeValue ?? "");
      const offsets = [];
      let joined = "";
      for (const t of texts) {
        offsets.push(joined.length);
        joined += t;
      }
      const hasNote = joined.includes(NOTE_PREFIX) && NOTE_RE.test(joined);
      const mightHave = this.matcher.size > 0 && this.matcher.mightContain(joined);
      if (!hasNote && !mightHave) return { count: 0, keys: [], unresolved: false, deferred: false };
      const edits = [];
      let unresolved = false;
      let deferred = false;
      if (hasNote) edits.push({ start: 0, end: NOTE_RE.exec(joined)[0].length, value: "" });
      if (mightHave) {
        for (const v of this.matcher.find(joined)) {
          if (!final && !v.complete && v.end === joined.length) {
            deferred = true;
            continue;
          }
          const value = this.source.value(v.key);
          if (value === void 0) {
            need.add(v.key);
            unresolved = true;
            continue;
          }
          if (edits.some((e) => v.start < e.end && v.end > e.start)) continue;
          edits.push({ start: v.start, end: v.end, value, key: v.key });
        }
      }
      if (edits.length === 0) return { count: 0, keys: [], unresolved, deferred };
      edits.sort((a, b) => a.start - b.start);
      const nodeOf = (pos) => {
        let i = offsets.length - 1;
        while (i > 0 && offsets[i] > pos) i--;
        return i;
      };
      const perNode = nodes.map(() => []);
      for (const e of edits) {
        const first = nodeOf(e.start);
        const last = nodeOf(Math.max(e.start, e.end - 1));
        for (let i = first; i <= last; i++) {
          const nodeStart = offsets[i];
          perNode[i].push({
            from: Math.max(e.start, nodeStart) - nodeStart,
            to: Math.min(e.end, nodeStart + texts[i].length) - nodeStart,
            value: i === first ? e.value : "",
            key: i === first ? e.key : void 0
          });
        }
      }
      const keys = [];
      nodes.forEach((node, i) => {
        const list = perNode[i];
        if (list.length === 0) return;
        const original = texts[i];
        let out = "";
        let pos = 0;
        const spans = [];
        for (const e of list) {
          out += original.slice(pos, e.from);
          const start = out.length;
          out += e.value;
          if (e.key && e.value) {
            spans.push([start, out.length]);
            keys.push(e.key);
          }
          pos = e.to;
        }
        out += original.slice(pos);
        if (out === original) return;
        const prev = this.records.get(node);
        const masked = prev && original === prev.restored ? prev.masked : original;
        if (prev) this.unpaint(prev);
        const rec = { masked, restored: out, spans, ranges: [] };
        node.nodeValue = out;
        this.records.set(node, rec);
        this.tracked.add(new WeakRef(node));
        this.paint(node, rec);
        this.onTracked?.();
      });
      return { count: keys.length, keys, unresolved, deferred };
    }
    // ---- highlighting ---------------------------------------------------------------------
    setupHighlight() {
      const win = this.win;
      if (this.highlight || !win.CSS?.highlights || typeof win.Highlight !== "function") return;
      this.highlight = new win.Highlight();
      win.CSS.highlights.set(HIGHLIGHT_NAME, this.highlight);
      this.maskedHighlight = new win.Highlight();
      win.CSS.highlights.set(MASKED_HIGHLIGHT_NAME, this.maskedHighlight);
      try {
        if (typeof win.CSSStyleSheet === "function" && "adoptedStyleSheets" in this.doc) {
          const sheet = new win.CSSStyleSheet();
          sheet.replaceSync(
            `::highlight(${HIGHLIGHT_NAME}) { background-color: rgba(46, 230, 197, 0.28); color: inherit; text-decoration: underline dotted rgba(46, 230, 197, 0.9); }
::highlight(${MASKED_HIGHLIGHT_NAME}) { background-color: rgba(255, 179, 71, 0.3); color: inherit; text-decoration: underline wavy rgba(255, 140, 40, 0.9); }`
          );
          this.doc.adoptedStyleSheets = [...this.doc.adoptedStyleSheets, sheet];
        }
      } catch {
      }
    }
    unpaint(rec) {
      for (const r of rec.ranges) this.highlight?.delete(r);
      rec.ranges = [];
    }
    paint(node, rec) {
      if (!this.highlight) return;
      this.unpaint(rec);
      for (const [start, end] of rec.spans) {
        try {
          const range = this.doc.createRange();
          range.setStart(node, start);
          range.setEnd(node, end);
          this.highlight.add(range);
          rec.ranges.push(range);
        } catch {
        }
      }
    }
    /** What the AI got: every placeholder in the restored nodes, picked out. */
    paintMasked() {
      if (!this.maskedHighlight) return;
      this.maskedHighlight.clear();
      for (const ref of this.tracked) {
        const node = ref.deref();
        if (!node || !node.isConnected) continue;
        const text = node.nodeValue ?? "";
        for (const m of text.matchAll(/\{\{[A-Z0-9_]+\}\}/g)) {
          try {
            const range = this.doc.createRange();
            range.setStart(node, m.index ?? 0);
            range.setEnd(node, (m.index ?? 0) + m[0].length);
            this.maskedHighlight.add(range);
          } catch {
          }
        }
      }
    }
    /** True once anything on the page has been restored. */
    get hasRestored() {
      return this.tracked.size > 0;
    }
    paintAll() {
      if (!this.highlight) return;
      this.highlight.clear();
      for (const ref of this.tracked) {
        const node = ref.deref();
        const rec = node ? this.records.get(node) : void 0;
        if (node && rec) this.paint(node, rec);
      }
    }
    /** Puts every node back (Zuko turned off for this site). */
    revert() {
      for (const ref of this.tracked) {
        const node = ref.deref();
        const rec = node ? this.records.get(node) : void 0;
        if (node && rec && node.isConnected) node.nodeValue = rec.masked;
      }
      this.tracked.clear();
      this.highlight?.clear();
    }
  };

  // src/shared/mascot.ts
  var NS = "http://www.w3.org/2000/svg";
  var uid = 0;
  function el(doc, tag, attrs = {}, kids = []) {
    const e = doc.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
    for (const c of kids) e.appendChild(c);
    return e;
  }
  function stop(doc, offset, color) {
    return el(doc, "stop", { offset, "stop-color": color });
  }
  function mascotSvg(doc) {
    const n = ++uid;
    const head = `zk-head-${n}`;
    const eye = `zk-eye-${n}`;
    const defs = el(doc, "defs", {}, [
      el(doc, "radialGradient", { id: head, cx: "36%", cy: "28%", r: "78%" }, [
        stop(doc, 0, "#FFFFFF"),
        stop(doc, 0.3, "#F7F3EE"),
        stop(doc, 0.8, "#E8D5C4"),
        stop(doc, 1, "#CBAE96")
      ]),
      el(doc, "radialGradient", { id: eye, cx: "50%", cy: "55%", r: "60%" }, [
        stop(doc, 0, "#FFF3CF"),
        stop(doc, 0.45, "#FFB347"),
        stop(doc, 1, "#F28A1E")
      ])
    ]);
    const dark = "#2B1D1A";
    const outline = "#1E1310";
    const almond = (cx, mirror) => el(doc, "path", {
      d: "M-5.2 1.6 C-3 -4.2 2.6 -5.8 5.4 -3 C5.2 2.8 1.2 6 -2 5.6 C-3.8 5.2 -5 3.6 -5.2 1.6Z",
      transform: `translate(${cx} 38) scale(${mirror} 1)`,
      fill: `url(#${eye})`,
      stroke: "#B5400E",
      "stroke-width": 0.8
    });
    const svg = el(doc, "svg", { viewBox: "0 0 64 64", width: "100%", height: "100%", "aria-hidden": "true", focusable: "false" }, [
      defs,
      // Ponytail swoosh and topknot behind the head.
      el(doc, "path", { d: "M33 13 C41 1 58 5 60 26 C60 33 56 36 55 40 C54 32 52 20 40 17Z", fill: dark, stroke: outline, "stroke-width": 1, "stroke-linejoin": "round" }),
      el(doc, "ellipse", { cx: 32, cy: 10, rx: 6.2, ry: 5, fill: dark, stroke: outline, "stroke-width": 1 }),
      // Maroon tunic with a gold collar.
      el(doc, "path", { d: "M14 64 C15 54 24 52 32 56 C40 52 49 54 50 64Z", fill: "#6E1F18", stroke: outline, "stroke-width": 1, "stroke-linejoin": "round" }),
      el(doc, "path", { d: "M22 54 C27 58 37 58 42 54", fill: "none", stroke: "#E0A030", "stroke-width": 2, "stroke-linecap": "round" }),
      // Head.
      el(doc, "circle", { cx: 32, cy: 35, r: 22, fill: `url(#${head})`, stroke: outline, "stroke-width": 1.6 }),
      // Flame scar round the viewer's right eye.
      el(doc, "path", { d: "M36 40 C33 32 36 26 40 27 C41 25 43 26 43.5 24.5 C46 27 52 29 53 36 C54 44 48 48 42 47 C38 46.5 36.5 43.5 36 40Z", fill: "#B33A2E", opacity: 0.45 }),
      // Eyes.
      almond(23, -1),
      almond(41, 1),
      el(doc, "ellipse", { cx: 22.4, cy: 38, rx: 1.3, ry: 1.7, fill: "#FFFBEA", opacity: 0.85 }),
      el(doc, "ellipse", { cx: 40.4, cy: 38, rx: 1.3, ry: 1.7, fill: "#FFFBEA", opacity: 0.85 }),
      // Highlight.
      el(doc, "ellipse", { cx: 22, cy: 22.5, rx: 6, ry: 3.2, transform: "rotate(-35 22 22.5)", fill: "#FFFFFF", opacity: 0.8 }),
      // Hair-tie.
      el(doc, "rect", { x: 28.4, y: 11.6, width: 7.2, height: 4.6, rx: 1.4, fill: "#B33A2E", stroke: outline, "stroke-width": 0.8 }),
      el(doc, "rect", { x: 28.4, y: 12.8, width: 7.2, height: 0.9, fill: "#E0A030" })
    ]);
    return svg;
  }

  // src/content/toast.ts
  var CSS = `
:host { all: initial; }
.layer { position: fixed; z-index: 2147483647; right: 16px; bottom: 16px; display: flex; flex-direction: column; gap: 8px; align-items: flex-end; pointer-events: none; font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; }
.toast { pointer-events: auto; max-width: 380px; color: #f6ece2; background: #1a100d; border: 1px solid #4a2d25; border-left: 4px solid #ffb347; border-radius: 10px; padding: 10px 12px; box-shadow: 0 8px 28px rgba(0,0,0,.45); display: flex; gap: 10px; align-items: flex-start; animation: in .16s ease-out; }
.toast.warn { border-left-color: #e0a030; }
.toast.error { border-left-color: #e5503f; }
.toast .msg { flex: 1; white-space: pre-wrap; word-break: break-word; }
.toast .brand { font-weight: 700; color: #ffb347; margin-right: 6px; }
.toast.warn .brand { color: #e0a030; }
.toast.error .brand { color: #e5503f; }
.toast button { all: unset; cursor: pointer; color: #ffb347; font-weight: 600; padding: 2px 6px; border-radius: 6px; }
.toast button:hover { background: rgba(255,179,71,.16); }
.toast .x { color: #b59a88; font-weight: 400; }
.chip { position: fixed; pointer-events: auto; display: none; align-items: center; gap: 6px; color: #f6ece2; background: #1a100d; border: 1px solid #4a2d25; border-radius: 999px; padding: 3px 10px 3px 8px; font: 12px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; box-shadow: 0 4px 16px rgba(0,0,0,.35); cursor: default; }
.chip.on { display: inline-flex; }
.chip .dot { width: 8px; height: 8px; border-radius: 50%; background: #ffb347; box-shadow: 0 0 8px #ffb347; }
.chip.warn .dot { background: #e0a030; box-shadow: 0 0 8px #e0a030; }
.switch { position: fixed; right: 18px; bottom: 120px; pointer-events: auto; display: none; align-items: center; gap: 2px; padding: 3px; background: #1a100d; border: 1px solid #4a2d25; border-radius: 999px; box-shadow: 0 6px 22px rgba(0,0,0,.4); font: 600 12px/1.2 system-ui, -apple-system, "Segoe UI", sans-serif; }
.switch.on { display: inline-flex; }
.switch .tag { color: #ffb347; padding: 0 6px 0 8px; }
.switch button { all: unset; cursor: pointer; color: #b59a88; padding: 5px 10px; border-radius: 999px; }
.switch button:hover { color: #f6ece2; }
.switch button.sel { color: #1a100d; background: #2ee6c5; }
.switch button.sel.ai { background: #ffb347; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
.avatar { position: relative; flex: none; width: 26px; height: 26px; margin-top: -1px; }
.avatar svg { display: block; width: 26px; height: 26px; }
.flame { position: absolute; right: -5px; top: -7px; width: 9px; height: 13px; background: radial-gradient(ellipse at 50% 75%, #fff3cf 0 18%, #ffb347 40%, #e5503f 85%); transform-origin: 50% 100%; animation: flick .9s ease-in-out infinite alternate; clip-path: polygon(50% 0, 78% 38%, 100% 70%, 82% 100%, 18% 100%, 0 70%, 24% 36%); }
@keyframes flick { 0% { transform: scale(1, 1) rotate(-4deg); opacity: .9; } 50% { transform: scale(.88, 1.15) rotate(3deg); opacity: 1; } 100% { transform: scale(1.05, .92) rotate(-2deg); opacity: .85; } }
@media (prefers-reduced-motion: reduce) { .toast, .flame { animation: none; } }
`;
  var Overlay = class {
    doc;
    host;
    layer;
    chipEl;
    chipText;
    mounted = false;
    switchEl;
    yoursBtn;
    aiBtn;
    pick = () => {
    };
    constructor(doc) {
      this.doc = doc;
      this.host = doc.createElement("zuko-overlay");
      const root = this.host.attachShadow({ mode: "closed" });
      const win = doc.defaultView;
      let styled = false;
      try {
        if (win && "adoptedStyleSheets" in root && typeof win.CSSStyleSheet === "function") {
          const sheet = new win.CSSStyleSheet();
          sheet.replaceSync(CSS);
          root.adoptedStyleSheets = [sheet];
          styled = true;
        }
      } catch {
        styled = false;
      }
      if (!styled) {
        const style = doc.createElement("style");
        style.textContent = CSS;
        root.appendChild(style);
      }
      this.layer = doc.createElement("div");
      this.layer.className = "layer";
      this.layer.setAttribute("role", "status");
      this.layer.setAttribute("aria-live", "polite");
      this.chipEl = doc.createElement("div");
      this.chipEl.className = "chip";
      const dot = doc.createElement("span");
      dot.className = "dot";
      this.chipText = doc.createElement("span");
      this.chipEl.append(dot, this.chipText);
      this.switchEl = doc.createElement("div");
      this.switchEl.className = "switch";
      const tag = doc.createElement("span");
      tag.className = "tag";
      tag.textContent = "Zuko";
      this.yoursBtn = doc.createElement("button");
      this.yoursBtn.type = "button";
      this.yoursBtn.textContent = "Your view";
      this.yoursBtn.title = "Real values, restored on this computer only";
      this.yoursBtn.addEventListener("click", () => this.pick(true));
      this.aiBtn = doc.createElement("button");
      this.aiBtn.type = "button";
      this.aiBtn.addEventListener("click", () => this.pick(false));
      this.switchEl.append(tag, this.yoursBtn, this.aiBtn);
      root.append(this.layer, this.chipEl, this.switchEl);
    }
    /**
     * The view switch: shown once something on the page was restored. `revealed` is the
     * current view (true = real values); `pick` is called with the one the user chose.
     */
    setSwitch(opts) {
      this.mount();
      this.pick = opts.pick;
      this.aiBtn.textContent = `What ${opts.aiName} got`;
      this.aiBtn.title = `Your messages and its replies exactly as ${opts.aiName} has them: placeholders, never your values (Alt+R)`;
      this.switchEl.classList.toggle("on", opts.visible);
      this.yoursBtn.classList.toggle("sel", opts.revealed);
      this.aiBtn.classList.toggle("sel", !opts.revealed);
      this.aiBtn.classList.toggle("ai", !opts.revealed);
    }
    mount() {
      if (this.mounted && this.host.isConnected) return;
      (this.doc.documentElement ?? this.doc.body).appendChild(this.host);
      this.mounted = true;
    }
    show(opts) {
      this.mount();
      const level = opts.level ?? "info";
      const el2 = this.doc.createElement("div");
      el2.className = `toast ${level}`;
      const avatar = this.doc.createElement("div");
      avatar.className = "avatar";
      avatar.appendChild(mascotSvg(this.doc));
      if (opts.flame ?? (level !== "info" || /mask/i.test(opts.text))) {
        const flame = this.doc.createElement("span");
        flame.className = "flame";
        avatar.appendChild(flame);
      }
      el2.appendChild(avatar);
      const msg = this.doc.createElement("div");
      msg.className = "msg";
      const brand = this.doc.createElement("span");
      brand.className = "brand";
      brand.textContent = "Zuko";
      msg.append(brand, this.doc.createTextNode(opts.text));
      el2.appendChild(msg);
      const close = () => el2.remove();
      for (const a of opts.actions ?? []) {
        const b = this.doc.createElement("button");
        b.type = "button";
        b.textContent = a.label;
        b.addEventListener("click", () => {
          a.run();
          close();
        });
        el2.appendChild(b);
      }
      const x = this.doc.createElement("button");
      x.type = "button";
      x.className = "x";
      x.textContent = "×";
      x.setAttribute("aria-label", "Dismiss");
      x.addEventListener("click", close);
      el2.appendChild(x);
      this.layer.appendChild(el2);
      while (this.layer.children.length > 4) this.layer.firstElementChild?.remove();
      const ttl = opts.ttl ?? (level === "error" ? 14e3 : 6e3);
      if (ttl > 0) this.doc.defaultView?.setTimeout(close, ttl);
      return close;
    }
    /** The composer chip: text, level and anchor rectangle; `null` text hides it. */
    chip(text, level = "info", anchor, title) {
      if (text === null) {
        this.chipEl.classList.remove("on");
        return;
      }
      this.mount();
      this.chipText.textContent = text;
      this.chipEl.title = title ?? "";
      this.chipEl.classList.toggle("warn", level === "warn");
      this.chipEl.classList.add("on");
      if (anchor) {
        const win = this.doc.defaultView;
        const w = this.chipEl.offsetWidth || 180;
        const left = Math.max(8, Math.min(win.innerWidth - w - 8, anchor.right - w));
        const top = Math.max(8, anchor.top - 30);
        this.chipEl.style.left = `${left}px`;
        this.chipEl.style.top = `${top}px`;
      }
    }
  };

  // src/shared/files.ts
  var TEXT_EXT = /\.(txt|md|markdown|json|jsonl|ndjson|csv|tsv|log|xml|ya?ml|toml|ini|env|cfg|conf|properties|html?|css|scss|less|svg|[cm]?[jt]sx?|vue|svelte|py|rb|go|rs|java|kt|kts|scala|c|h|cc|cpp|hpp|cs|php|sh|bash|zsh|ps1|psm1|bat|cmd|sql|swift|dart|lua|r|pl|ex|exs|tf|gradle)$/i;
  var PDF_EXT = /\.pdf$/i;
  var TEXT_TYPE = /^text\/|json|xml|javascript|ecmascript|csv|markdown|yaml|toml|x-www-form-urlencoded|x-sh\b|x-python|x-ruby|x-rust|x-go|x-java/i;
  function isTextLikeName(name) {
    return TEXT_EXT.test(name);
  }
  function isTextLikeType(type) {
    return TEXT_TYPE.test(type);
  }
  function isPdf(file) {
    return file.type === "application/pdf" || PDF_EXT.test(file.name);
  }
  function hasNoRealExtension(name) {
    const base = name.split(/[\\/]/).pop() ?? name;
    return !/\.[^.]+$/.test(base) || /^\.[^.]+$/.test(base);
  }
  function isScannableText(file) {
    if (isPdf(file)) return false;
    return isTextLikeName(file.name) || isTextLikeType(file.type) || file.type === "" && hasNoRealExtension(file.name);
  }
  var MAX_SCAN_BYTES = 16 * 1024 * 1024;

  // src/content/uploads.ts
  var OFFICE = /\.(docx?|xlsx?|pptx?|odt|ods|odp|rtf|zip|7z|rar|tar|gz)$/i;
  function stem(name) {
    return name.replace(/\.[^.\\/]+$/, "");
  }
  function toBase64(buf) {
    const bytes = new Uint8Array(buf);
    let bin = "";
    for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(bin);
  }
  function plural(n, one, many) {
    return `${n} ${n === 1 ? one : many}`;
  }
  function needsSanitizing(file) {
    return isPdf(file) || isScannableText(file);
  }
  var isMarkdownish = (name) => /\.(txt|md|markdown)$/i.test(name) || !/\.[^.\\/]+$/.test(name);
  async function sanitizeFile(file, deps) {
    const Ctor = deps.File ?? File;
    const pass = (message = "", level = "info") => ({ file, count: 0, keys: [], changed: false, message, level });
    if (isPdf(file)) {
      if (file.size > 64 * 1024 * 1024) return pass(`${file.name} is too large for Zuko to scan (64 MB limit). It was not checked.`, "warn");
      const r = await deps.sanitizePdf(toBase64(await file.arrayBuffer()), file.name);
      if (!r.ok) {
        return { file: null, count: 0, keys: [], changed: true, level: "error", message: `Zuko could not read ${file.name} (${r.error ?? "unknown error"}), so it was not uploaded.` };
      }
      if (r.blocked) {
        return {
          file: null,
          count: 0,
          keys: [],
          changed: true,
          level: "error",
          message: `${file.name} has no text layer (a scanned PDF?). Zuko cannot check it for secrets, so it was not uploaded.`
        };
      }
      const count = r.count ?? 0;
      const keys = r.keys ?? [];
      let md = r.markdown ?? "";
      if (count > 0 && keys.length > 0) md = `${buildNote(keys)}

${md}`;
      const out = new Ctor([md], `${stem(file.name)}.zuko.md`, { type: "text/markdown", lastModified: file.lastModified });
      const warn = (r.warnings ?? []).join(" ");
      return {
        file: out,
        count,
        keys,
        changed: true,
        level: warn ? "warn" : "info",
        message: `${file.name} was replaced by a text-only copy (${out.name}, ${plural(r.pages ?? 0, "page", "pages")}). ` + (count > 0 ? `${plural(count, "item", "items")} masked.` : "Nothing sensitive found.") + (warn ? ` ${warn}` : "")
      };
    }
    if (isScannableText(file)) {
      if (file.size > MAX_SCAN_BYTES) return pass(`${file.name} is too large for Zuko to scan (16 MB limit). It was not checked.`, "warn");
      let text;
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(await file.arrayBuffer());
      } catch {
        return pass(`${file.name} is not UTF-8 text, so Zuko could not check it.`, "warn");
      }
      const r = await deps.maskText(text);
      if (r.count === 0 || r.text === text) return pass();
      const body = isMarkdownish(file.name) && r.keys.length > 0 ? `${buildNote(r.keys)}

${r.text}` : r.text;
      const out = new Ctor([body], file.name, { type: file.type || "text/plain", lastModified: file.lastModified });
      return {
        file: out,
        count: r.count,
        keys: r.keys,
        changed: true,
        level: "info",
        message: `${file.name}: ${plural(r.count, "item", "items")} masked before upload.`
      };
    }
    if (OFFICE.test(file.name)) return pass(`Zuko cannot look inside ${file.name}. Check it yourself before sending.`, "warn");
    return pass();
  }
  var UploadGuard = class {
    win;
    deps;
    bypass = 0;
    started = false;
    constructor(win, deps) {
      this.win = win;
      this.deps = deps;
    }
    start() {
      if (this.started) return;
      this.started = true;
      this.win.addEventListener("change", (e) => this.onChange(e), true);
      this.win.addEventListener("drop", (e) => this.onDrop(e), true);
      this.win.addEventListener("paste", (e) => this.onPaste(e), true);
    }
    /** Sanitizes a list of files and reports to the user. Order is kept; blocked files drop out. */
    async process(files) {
      const names = files.filter(needsSanitizing).map((f) => f.name);
      if (names.length > 0) this.deps.notify("info", `Checking ${names.length === 1 ? names[0] : names.length + " files"} for private data...`);
      const out = [];
      let totalCount = 0;
      const keys = /* @__PURE__ */ new Set();
      for (const f of files) {
        let s;
        try {
          s = await sanitizeFile(f, this.deps);
        } catch (e) {
          s = {
            file: needsSanitizing(f) ? null : f,
            count: 0,
            keys: [],
            changed: true,
            level: "error",
            message: `Zuko could not check ${f.name} (${e instanceof Error ? e.message : String(e)}), so it was not uploaded.`
          };
        }
        if (s.file) out.push(s.file);
        totalCount += s.count;
        s.keys.forEach((k) => keys.add(k));
        if (s.message) this.deps.notify(s.level, s.message);
      }
      if (totalCount > 0 || files.some(needsSanitizing)) this.deps.report(totalCount, [...keys]);
      return out;
    }
    /** Files Zuko cannot look inside: say so, but do not get in the way. */
    warnOpaque(files) {
      for (const f of files) if (OFFICE.test(f.name)) this.deps.notify("warn", `Zuko cannot look inside ${f.name}. Check it yourself before sending.`);
    }
    toTransfer(files) {
      const dt = new this.win.DataTransfer();
      for (const f of files) dt.items.add(f);
      return dt;
    }
    off() {
      return this.deps.enabled ? !this.deps.enabled() : false;
    }
    onChange(e) {
      if (this.off()) return;
      const input = e.target;
      if (this.bypass > 0 || !input || input.tagName !== "INPUT" || input.type !== "file" || !input.files?.length) return;
      const files = [...input.files];
      if (!files.some(needsSanitizing)) return this.warnOpaque(files);
      e.stopImmediatePropagation();
      void this.process(files).then((clean) => {
        try {
          input.files = this.toTransfer(clean).files;
        } catch {
          input.value = "";
          this.deps.notify("error", "Zuko could not swap the checked file in, so the selection was cleared. Please choose the file again.");
          return;
        }
        this.bypass++;
        try {
          input.dispatchEvent(new this.win.Event("change", { bubbles: true }));
        } finally {
          this.bypass--;
        }
      });
    }
    onDrop(e) {
      if (this.off()) return;
      const dt = e.dataTransfer;
      if (this.bypass > 0 || !dt || !dt.files || dt.files.length === 0) return;
      const files = [...dt.files];
      if (!files.some(needsSanitizing)) return this.warnOpaque(files);
      e.preventDefault();
      e.stopImmediatePropagation();
      const target = e.target;
      void this.process(files).then((clean) => {
        if (!(target instanceof this.win.EventTarget)) return;
        this.bypass++;
        try {
          target.dispatchEvent(
            new this.win.DragEvent("drop", {
              bubbles: true,
              cancelable: true,
              dataTransfer: this.toTransfer(clean),
              clientX: e.clientX,
              clientY: e.clientY
            })
          );
        } finally {
          this.bypass--;
        }
      });
    }
    onPaste(e) {
      if (this.off()) return;
      const dt = e.clipboardData;
      if (this.bypass > 0 || !dt || !dt.files || dt.files.length === 0) return;
      const files = [...dt.files];
      if (!files.some(needsSanitizing)) return this.warnOpaque(files);
      e.preventDefault();
      e.stopImmediatePropagation();
      const target = e.target;
      void this.process(files).then((clean) => {
        if (!(target instanceof this.win.EventTarget)) return;
        this.bypass++;
        try {
          target.dispatchEvent(
            new this.win.ClipboardEvent("paste", { bubbles: true, cancelable: true, clipboardData: this.toTransfer(clean) })
          );
        } finally {
          this.bypass--;
        }
      });
    }
  };

  // src/content/values.ts
  var SwValues = class {
    known = /* @__PURE__ */ new Set();
    cache = /* @__PURE__ */ new Map();
    send;
    constructor(send) {
      this.send = send;
    }
    keys() {
      return this.known;
    }
    value(key) {
      return this.cache.get(key);
    }
    async load(keys) {
      const need = keys.filter((k) => !this.cache.has(k));
      if (need.length === 0) return;
      const r = await this.send({ type: "resolve", keys: need });
      if (!r?.ok) return;
      for (const [k, v] of Object.entries(r.values)) this.cache.set(k, v.value);
    }
    /** Re-reads the list of known keys. Returns true when it changed. */
    async refreshKeys() {
      const r = await this.send({ type: "known" });
      if (!r?.ok) return false;
      const next = new Set(r.keys);
      const changed = next.size !== this.known.size || [...next].some((k) => !this.known.has(k));
      this.known = next;
      for (const k of [...this.cache.keys()]) if (!next.has(k)) this.cache.delete(k);
      return changed;
    }
  };

  // src/shared/protocol.ts
  var STORAGE_PREFS = "zuko.prefs";
  var STORAGE_SYNC = "zuko.sync";

  // src/shared/sites.ts
  var HOSTS = {
    "chatgpt.com": "chatgpt",
    "chat.openai.com": "chatgpt",
    "claude.ai": "claude",
    "chat.deepseek.com": "deepseek"
  };
  function siteForHost(host) {
    return HOSTS[host.toLowerCase()] ?? null;
  }

  // src/content/index.ts
  var site = siteForHost(location.hostname);
  if (site && !window.__zukoContent) {
    Object.defineProperty(window, "__zukoContent", { value: true, enumerable: false });
    main(site);
  }
  function main(site2) {
    const win = window;
    const isTop = win === win.top;
    let overlay = null;
    const ui = () => overlay ??= new Overlay(document);
    let enabled = true;
    let vaultSize = 0;
    let engine = true;
    let invalidatedShown = false;
    const notify = (level, text, ttl) => {
      if (isTop) ui().show({ level, text, ttl });
      else void send({ type: "toast", level, text });
    };
    const send = async (msg) => {
      try {
        if (!chrome.runtime?.id) throw new Error("Extension context invalidated.");
        const reply = await chrome.runtime.sendMessage(msg);
        return reply ?? { ok: false, error: "engine-unavailable" };
      } catch (e) {
        if (!invalidatedShown && /context invalidated|Receiving end does not exist/i.test(String(e?.message ?? e))) {
          invalidatedShown = true;
          notify(
            "warn",
            "Zuko was reloaded or updated. Reload this page to restore full protection. Until then, messages with obvious secrets are blocked.",
            0
          );
        }
        return { ok: false, error: "engine-unavailable" };
      }
    };
    const kindsOf = (keys) => [...new Set(keys.map((k) => k.replace(/_\d+$/, "").replace(/_/g, " ").toLowerCase()))].slice(0, 4).join(", ");
    const values = new SwValues(send);
    let rehydrator = null;
    let chip = null;
    const bridge = new ContentBridge(win, {
      async request(req) {
        switch (req.type) {
          case "maskMany": {
            const r = await send({ type: "maskMany", site: site2, texts: req.texts, mode: req.mode, source: req.source });
            if (!r.ok) throw new Error(r.error ?? "engine-unavailable");
            if (r.count > 0) {
              vaultSize = Math.max(vaultSize, 1);
              if (req.mode === "full" && !req.source) {
                notify("info", `Masked ${r.count} ${r.count === 1 ? "item" : "items"} before sending${r.keys.length ? ` (${kindsOf(r.keys)})` : ""}.`, 4500);
              }
            }
            return { texts: r.texts, count: r.count, keys: r.keys, newKeys: r.newKeys };
          }
          case "tripwire": {
            const r = await send({ type: "tripwire", site: site2, texts: req.texts, url: req.url });
            if (!r.ok) throw new Error(r.error ?? "engine-unavailable");
            if (r.action === "masked") notify("warn", `Removed ${r.count} protected ${r.count === 1 ? "value" : "values"} from an outgoing request.`, 6e3);
            return r;
          }
          case "clipboard":
            return writeRestoredClipboard(req.items, {
              doc: document,
              matcher: () => rehydrator?.variantMatcher ?? EMPTY_MATCHER(),
              source: values
            });
        }
      },
      notify: (level, text) => notify(level, text),
      event: (kind, count, keys) => void send({ type: "event", site: site2, kind, count, keys })
    });
    bridge.start();
    const pushState = () => bridge.pushState({ enabled, vaultSize, engine });
    const applyEnabled = () => {
      if (!isTop) return;
      if (rehydrator) {
        if (enabled) rehydrator.start();
        else rehydrator.stop();
      }
      if (!enabled) overlay?.setSwitch({ visible: false, revealed: true, aiName: AI_NAME[site2], pick: () => {
      } });
      chip?.setEnabled(enabled);
    };
    const onVaultChanged = async () => {
      const changed = await values.refreshKeys();
      if (changed) rehydrator?.refresh();
    };
    void send({ type: "state", site: site2 }).then((r) => {
      if (!r.ok) {
        engine = false;
        pushState();
        return;
      }
      enabled = r.enabled !== false;
      engine = r.engine === true;
      vaultSize = Number(r.vaultSize) || 0;
      pushState();
      applyEnabled();
    });
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        const prefs = changes[STORAGE_PREFS]?.newValue;
        if (prefs) {
          enabled = prefs.sites?.[site2] !== false;
          pushState();
          applyEnabled();
        }
        const sync = changes[STORAGE_SYNC]?.newValue;
        if (sync) {
          vaultSize = sync.vaultSize;
          engine = sync.engine;
          pushState();
          if (isTop) void onVaultChanged();
        }
      });
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.type === "toast" && isTop && typeof msg.text === "string") ui().show({ level: msg.level === "error" || msg.level === "warn" ? msg.level : "info", text: msg.text });
        return false;
      });
    } catch {
    }
    new UploadGuard(win, {
      enabled: () => enabled,
      maskText: async (text) => {
        const r = await send({ type: "maskMany", site: site2, texts: [text], mode: "full", source: "file" });
        if (!r.ok) throw new Error(r.error ?? "engine-unavailable");
        return { text: r.texts[0], count: r.count, keys: r.keys };
      },
      sanitizePdf: async (base64, name) => await send({ type: "sanitize-pdf", site: site2, name, base64 }),
      notify: (level, text) => notify(level, text),
      report: (count, keys) => void send({ type: "event", site: site2, kind: "upload", count, keys })
    }).start();
    if (!isTop) return;
    const onReady = (fn) => {
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn, { once: true });
      else fn();
    };
    onReady(() => {
      let restoredPending = 0;
      let restoredTimer = null;
      rehydrator = new Rehydrator({
        doc: document,
        site: site2,
        source: values,
        onRestored: (count) => {
          restoredPending += count;
          restoredTimer ??= setTimeout(() => {
            void send({ type: "event", site: site2, kind: "restored", count: restoredPending, keys: [] });
            restoredPending = 0;
            restoredTimer = null;
          }, 2500);
        },
        onToggle: (revealed) => {
          paintSwitch();
          notify(
            "info",
            revealed ? "Your view: real values, on this computer only." : `What ${AI_NAME[site2]} got: the highlighted placeholders are all it ever saw of your data.`,
            3500
          );
        },
        onTracked: () => paintSwitch()
      });
      const paintSwitch = () => ui().setSwitch({
        visible: enabled && !!rehydrator?.hasRestored,
        revealed: rehydrator?.isRevealed ?? true,
        aiName: AI_NAME[site2],
        pick: (revealed) => {
          if (rehydrator && rehydrator.isRevealed !== revealed) rehydrator.toggle();
        }
      });
      chip = new ComposerChip(document, site2, ui(), (text) => send({ type: "scan", text }));
      chip.start();
      chip.setEnabled(enabled);
      installCopyHandler({ doc: document, matcher: () => rehydrator.variantMatcher, source: values, enabled: () => enabled });
      win.addEventListener(
        "keydown",
        (e) => {
          if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && e.code === "KeyR" && enabled) {
            e.preventDefault();
            e.stopImmediatePropagation();
            rehydrator?.toggle();
          }
        },
        true
      );
      void values.refreshKeys().then(() => {
        rehydrator.refresh();
        if (enabled) rehydrator.start();
      });
    });
  }
  var EMPTY_MATCHER = () => new VariantMatcher([]);
  var AI_NAME = { chatgpt: "ChatGPT", claude: "Claude", deepseek: "DeepSeek" };
})();
