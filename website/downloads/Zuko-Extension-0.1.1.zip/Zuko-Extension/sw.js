// src/shared/engine.ts
var EngineError = class extends Error {
};
var enc = new TextEncoder();
var dec = new TextDecoder("utf-8", { fatal: true });
var WasmEngine = class _WasmEngine {
  x;
  constructor(x) {
    this.x = x;
  }
  static async load(source) {
    let instance;
    if (source instanceof WebAssembly.Module) {
      instance = await WebAssembly.instantiate(source, {});
    } else if (source instanceof Promise) {
      instance = (await WebAssembly.instantiateStreaming(source, {})).instance;
    } else {
      instance = (await WebAssembly.instantiate(source, {})).instance;
    }
    const x = instance.exports;
    for (const name of ["memory", "zuko_alloc", "zuko_free", "zuko_call"]) {
      if (!(name in x)) throw new EngineError(`zuko_core.wasm lacks the "${name}" export`);
    }
    return new _WasmEngine(x);
  }
  call(request) {
    const input = enc.encode(JSON.stringify(request));
    const { memory, zuko_alloc, zuko_free, zuko_call } = this.x;
    const ptr = zuko_alloc(input.length);
    new Uint8Array(memory.buffer, ptr, input.length).set(input);
    const packed = zuko_call(ptr, input.length);
    zuko_free(ptr, input.length);
    const outPtr = Number(packed >> 32n);
    const outLen = Number(packed & 0xffffffffn);
    const text = dec.decode(new Uint8Array(memory.buffer, outPtr, outLen).slice());
    zuko_free(outPtr, outLen);
    return JSON.parse(text);
  }
};
var Engine = class {
  transport;
  constructor(transport) {
    this.transport = transport;
  }
  ok(req) {
    const r = this.transport.call(req);
    if (!r || r.ok !== true) throw new EngineError(String(r?.error ?? `engine op ${String(req.op)} failed`));
    return r;
  }
  configure(detector) {
    this.ok(detector ? { op: "configure", detector } : { op: "configure" });
  }
  loadVault(vault) {
    return this.ok({ op: "loadVault", vault }).size;
  }
  exportVault() {
    const v = this.ok({ op: "exportVault" }).vault;
    return { entries: v.entries ?? [], counters: v.counters ?? {} };
  }
  scan(text) {
    return this.ok({ op: "scan", text }).findings;
  }
  mask(text, source = "browser", now = Math.floor(Date.now() / 1e3)) {
    const r = this.ok({ op: "mask", text, source, now });
    return { text: r.text, report: r.report };
  }
  maskKnown(text) {
    const r = this.ok({ op: "maskKnown", text });
    return { text: r.text, count: r.count };
  }
  rehydrate(text) {
    const r = this.ok({ op: "rehydrate", text });
    return { text: r.text, keys: r.keys };
  }
  legend(keys) {
    return this.ok({ op: "legend", keys }).text;
  }
  views() {
    return this.ok({ op: "views" }).entries;
  }
};

// src/shared/placeholders.ts
var KEY_RE = /^([A-Z][A-Z0-9_]*[A-Z0-9])_([1-9]\d*)$|^([A-Z])_([1-9]\d*)$/;
function parseKey(key) {
  const m = KEY_RE.exec(key);
  if (!m) return null;
  return { kind: m[1] ?? m[3], n: Number(m[2] ?? m[4]) };
}
function wrap(key) {
  return `{{${key}}}`;
}
function canonicalKeys(text) {
  const out = [];
  for (const m of text.matchAll(/\{\{ ?([A-Z][A-Z0-9_]*_[1-9]\d*) ?\}\}/g)) out.push(m[1]);
  return out;
}

// src/shared/vault.ts
function mergeVaults(local, remote) {
  const entries = remote.entries.map((e) => ({ ...e }));
  const byValue = new Set(entries.map((e) => e.value));
  const usedKeys = new Set(entries.map((e) => e.key));
  const counters = { ...remote.counters };
  const bump = (key) => {
    const p = parseKey(key);
    if (p && (counters[p.kind] ?? 0) < p.n) counters[p.kind] = p.n;
  };
  entries.forEach((e) => bump(e.key));
  const renamed = [];
  for (const e of local.entries) {
    if (byValue.has(e.value)) continue;
    let key = e.key;
    if (usedKeys.has(key)) {
      const kind = parseKey(key)?.kind ?? e.kind;
      const next = Math.max(counters[kind] ?? 0, local.counters[kind] ?? 0) + 1;
      key = `${kind}_${next}`;
      renamed.push({ from: e.key, to: key });
    }
    usedKeys.add(key);
    byValue.add(e.value);
    entries.push({ ...e, key });
    bump(key);
  }
  for (const [kind, n] of Object.entries(local.counters)) if ((counters[kind] ?? 0) < n) counters[kind] = n;
  return { vault: { entries, counters }, renamed };
}
function mergeAddOnly(local, remote) {
  const entries = local.entries.map((e) => ({ ...e }));
  const values = new Set(entries.map((e) => e.value));
  const usedKeys = new Set(entries.map((e) => e.key));
  const counters = { ...local.counters };
  const bump = (key) => {
    const p = parseKey(key);
    if (p && (counters[p.kind] ?? 0) < p.n) counters[p.kind] = p.n;
  };
  entries.forEach((e) => bump(e.key));
  const added = [];
  for (const e of remote.entries) {
    if (typeof e.value !== "string" || e.value === "" || values.has(e.value)) continue;
    let key = e.key;
    if (usedKeys.has(key)) {
      const kind = parseKey(key)?.kind ?? e.kind;
      let n = Math.max(counters[kind] ?? 0, remote.counters?.[kind] ?? 0) + 1;
      while (usedKeys.has(`${kind}_${n}`)) n++;
      key = `${kind}_${n}`;
    }
    usedKeys.add(key);
    values.add(e.value);
    entries.push({ ...e, key });
    bump(key);
    added.push({ key, label: e.label });
  }
  for (const [kind, n] of Object.entries(remote.counters ?? {})) if ((counters[kind] ?? 0) < n) counters[kind] = n;
  return { vault: { entries, counters }, added };
}
var MIN_ENCODED_BYTES = 8;
function jsonEscaped(v) {
  return JSON.stringify(v).slice(1, -1);
}
function jsonEscapedAscii(v) {
  let out = "";
  for (const ch of jsonEscaped(v)) {
    if (ch.charCodeAt(0) < 128) out += ch;
    else for (let i = 0; i < ch.length; i++) out += "\\u" + ch.charCodeAt(i).toString(16).padStart(4, "0");
  }
  return out;
}
function toBase64(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/=+$/, "");
}
function base64Needles(value) {
  const bytes = new TextEncoder().encode(value);
  if (bytes.length < MIN_ENCODED_BYTES) return [];
  const out = /* @__PURE__ */ new Set();
  for (let k = 0; k < 3; k++) {
    const padded = new Uint8Array(k + bytes.length);
    padded.set(bytes, k);
    const enc2 = toBase64(padded);
    const start = [0, 2, 3][k];
    const end = (k + bytes.length) % 3 === 0 ? 0 : 1;
    const needle = enc2.slice(start, enc2.length - end);
    if (needle.length >= 8) {
      out.add(needle);
      out.add(needle.replace(/\+/g, "-").replace(/\//g, "_"));
    }
  }
  return [...out];
}
function entryEscapedNeedles(e) {
  const forms = /* @__PURE__ */ new Set();
  const esc = jsonEscaped(e.value);
  if (esc !== e.value) forms.add(esc);
  const ascii = jsonEscapedAscii(e.value);
  if (ascii !== e.value) forms.add(ascii);
  return [...forms].map((text) => ({ key: e.key, text }));
}
function entryEncodedNeedles(e) {
  const bytes = new TextEncoder().encode(e.value);
  if (bytes.length < MIN_ENCODED_BYTES) return [];
  const out = [];
  const url = encodeURIComponent(e.value);
  if (url !== e.value) out.push({ key: e.key, form: "url", text: url });
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  out.push({ key: e.key, form: "hex", text: hex }, { key: e.key, form: "hex", text: hex.toUpperCase() });
  for (const text of base64Needles(e.value)) out.push({ key: e.key, form: "base64", text });
  return out;
}

// src/background/brain.ts
var EngineUnavailable = class extends Error {
  constructor(message = "engine-unavailable") {
    super(message);
  }
};
var EMPTY_STATS = () => ({ masked: 0, blocked: 0, uploads: 0, restored: 0 });
var Brain = class {
  engine = null;
  engineError = null;
  link = null;
  rev = 0;
  needleRev = -1;
  escaped = [];
  encoded = [];
  values = /* @__PURE__ */ new Set();
  keySet = /* @__PURE__ */ new Set();
  stats = {};
  store;
  now;
  constructor(store, now = () => Math.floor(Date.now() / 1e3)) {
    this.store = store;
    this.now = now;
  }
  // ---- lifecycle -----------------------------------------------------------------------
  /** Attaches the engine and restores the session's detector settings, vault and counters. */
  async attach(engine, error = null) {
    this.engine = engine;
    this.engineError = engine ? null : error ?? "engine not loaded";
    this.stats = await this.store.get("stats") ?? {};
    if (!engine) return;
    const detector = await this.store.get("detector");
    if (detector) {
      try {
        engine.configure(detector);
      } catch {
      }
    }
    const vault = await this.store.get("vault");
    if (vault) {
      try {
        engine.loadVault(vault);
      } catch {
      }
    }
    this.rev++;
  }
  need() {
    if (!this.engine) throw new EngineUnavailable(this.engineError ?? "engine-unavailable");
    return this.engine;
  }
  get engineLoaded() {
    return this.engine !== null;
  }
  vaultSize() {
    return this.engine ? this.engine.exportVault().entries.length : 0;
  }
  // ---- vault ---------------------------------------------------------------------------
  async persistVault() {
    if (!this.engine) return;
    this.rev++;
    await this.store.set("vault", this.engine.exportVault());
  }
  /** Merges the desktop app's vault into the local one. Returns how many local keys were renumbered. */
  async adoptRemoteVault(remote) {
    const e = this.need();
    const { vault, renamed } = mergeVaults(e.exportVault(), remote);
    e.loadVault(vault);
    await this.persistVault();
    return renamed.length;
  }
  async applyDetector(detector) {
    const e = this.need();
    e.configure(detector);
    await this.store.set("detector", detector ?? void 0);
  }
  async clearVault() {
    const e = this.need();
    e.loadVault(null);
    await this.persistVault();
  }
  refreshNeedles() {
    if (this.needleRev === this.rev) return;
    const entries = this.need().exportVault().entries;
    this.escaped = entries.flatMap(entryEscapedNeedles);
    this.encoded = entries.flatMap(entryEncodedNeedles);
    this.values = new Set(entries.map((e) => e.value));
    this.keySet = new Set(entries.map((e) => e.key));
    this.needleRev = this.rev;
  }
  knownKeys() {
    return this.need().views().map((v) => v.key);
  }
  /** key -> value/kind/label for the keys that exist; the content script asks only for what it shows. */
  resolve(keys) {
    const entries = new Map(this.need().exportVault().entries.map((e) => [e.key, e]));
    const out = {};
    for (const k of keys) {
      const e = entries.get(k);
      if (e) out[k] = { value: e.value, kind: e.kind, label: e.label };
    }
    return out;
  }
  rehydrate(texts) {
    const e = this.need();
    const keys = /* @__PURE__ */ new Set();
    const out = texts.map((t) => {
      const r = e.rehydrate(t);
      r.keys.forEach((k) => keys.add(k));
      return r.text;
    });
    return { texts: out, keys: [...keys] };
  }
  // ---- masking -------------------------------------------------------------------------
  async maskMany(texts, opts) {
    const e = this.need();
    const out = [];
    const newKeys = /* @__PURE__ */ new Set();
    let count = 0;
    let via = "wasm";
    let touchedVault = false;
    let aiAdded = 0;
    for (const text of texts) {
      if (text === "") {
        out.push(text);
        continue;
      }
      if (opts.mode === "known") {
        const r = e.maskKnown(text);
        out.push(r.text);
        count += r.count;
        continue;
      }
      let report2 = null;
      let masked = null;
      const link2 = this.link;
      if (link2?.linked) {
        const r = await link2.mask(text, String(opts.site)).catch(() => null);
        if (r) {
          masked = r.text;
          report2 = r.report;
          via = "app";
          if (r.report.newKeys.length > 0) {
            const remote = await link2.fetchVault().catch(() => null);
            if (remote) await this.adoptRemoteVault(remote);
          } else if (r.text.includes("{{") && canonicalKeys(r.text).some((k) => !this.hasKey(k))) {
            const remote = await link2.fetchVault().catch(() => null);
            if (remote) await this.adoptRemoteVault(remote);
          }
        }
      }
      if (masked === null || report2 === null) {
        const r = e.mask(text, opts.source ?? "browser", this.now());
        masked = r.text;
        report2 = r.report;
        if (r.report.newKeys.length > 0) touchedVault = true;
      }
      count += report2.count;
      report2.newKeys.forEach((k) => newKeys.add(k));
      const ai = await this.aiPass(masked, String(opts.site), opts);
      masked = ai.text;
      count += ai.count;
      aiAdded += ai.added;
      ai.newKeys.forEach((k) => newKeys.add(k));
      out.push(masked);
    }
    if (touchedVault) await this.persistVault();
    const keys = /* @__PURE__ */ new Set();
    for (const t of out) if (t.includes("{{")) e.rehydrate(t).keys.forEach((k) => keys.add(k));
    return { texts: out, count, keys: [...keys], newKeys: [...newKeys], via, aiAdded };
  }
  hasKey(key) {
    this.refreshNeedles();
    return this.keySet.has(key);
  }
  /**
   * The desktop app's local-AI deep scan of text that is ALREADY masked (the deterministic
   * pass above is never skipped or changed). It can only add vault entries: merging is
   * add-only. For uploads, and when the app says prompts should wait, the request is held until
   * the scan is back and the text is re-masked with what it learned; otherwise the scan runs in
   * the background and later messages benefit. Any failure leaves the text exactly as it was.
   */
  async aiPass(masked, site, opts) {
    const none = { text: masked, count: 0, added: 0, newKeys: [] };
    const link2 = this.link;
    const ai = link2?.localAi;
    if (!link2?.linked || !link2.deepScan || !ai?.enabled || !ai.reachable || masked.trim().length < 6) return none;
    const e = this.need();
    const wait = opts.source === "file" || ai.waitForPromptScan;
    const apply = async (r) => {
      if (!r?.enabled || !r.vault || r.vault.entries.length === 0) return [];
      const { vault, added } = mergeAddOnly(e.exportVault(), r.vault);
      if (added.length === 0) return [];
      e.loadVault(vault);
      await this.persistVault();
      return added.map((a) => a.key);
    };
    if (!wait) {
      void link2.deepScan(masked, site, false).then(apply).then((keys2) => {
        if (keys2.length > 0) opts.onAiAdded?.(keys2.length);
      }).catch(() => void 0);
      return none;
    }
    let keys = [];
    try {
      keys = await apply(await link2.deepScan(masked, site, true));
    } catch {
      return none;
    }
    if (keys.length === 0) return none;
    const again = e.maskKnown(masked);
    opts.onAiAdded?.(keys.length);
    return { text: again.text, count: again.count, added: keys.length, newKeys: keys };
  }
  /** What the composer chip shows: how many distinct items would be masked. Never returns values. */
  scan(text) {
    const e = this.need();
    this.refreshNeedles();
    const findings = e.scan(text);
    const seen = /* @__PURE__ */ new Set();
    const items = [];
    for (const f of findings) {
      if (this.values.has(f.value) || seen.has(f.value)) continue;
      seen.add(f.value);
      items.push({ kind: f.kind, label: f.label ?? f.kind });
    }
    if (this.values.size > 0) {
      const known = e.maskKnown(text);
      if (known.count > 0) {
        const keys = new Set(e.rehydrate(known.text).keys);
        const views = new Map(e.views().map((v) => [v.key, v]));
        for (const k of keys) items.push({ kind: views.get(k)?.kind ?? k, label: views.get(k)?.label ?? k });
      }
    }
    return { count: items.length, items };
  }
  // ---- tripwire ------------------------------------------------------------------------
  /**
   * Exact-value check for any outgoing text: vault values (raw and JSON-escaped) become
   * placeholders; encoded copies (URL, base64, hex) cannot be fixed in place, so the request
   * is blocked.
   */
  tripwire(texts) {
    const e = this.need();
    this.refreshNeedles();
    if (this.values.size === 0) return { action: "pass", texts, count: 0, keys: [] };
    const blockedKeys = /* @__PURE__ */ new Set();
    for (const text of texts) {
      for (const n of this.encoded) if (text.includes(n.text)) blockedKeys.add(n.key);
    }
    if (blockedKeys.size > 0) {
      return {
        action: "block",
        reason: "an encoded copy of a protected value (URL-encoded, base64 or hex) is in this request",
        keys: [...blockedKeys]
      };
    }
    let count = 0;
    const keys = /* @__PURE__ */ new Set();
    const out = texts.map((text) => {
      let t = text;
      const r = e.maskKnown(t);
      if (r.count > 0) {
        count += r.count;
        t = r.text;
      }
      for (const n of this.escaped) {
        if (t.includes(n.text)) {
          const parts = t.split(n.text);
          count += parts.length - 1;
          t = parts.join(wrap(n.key));
        }
      }
      if (t !== text) e.rehydrate(t).keys.forEach((k) => keys.add(k));
      return t;
    });
    if (count === 0) return { action: "pass", texts, count: 0, keys: [] };
    return { action: "masked", texts: out, count, keys: [...keys] };
  }
  // ---- counters ------------------------------------------------------------------------
  async bump(site, field, by = 1) {
    if (by <= 0) return;
    const s = this.stats[site] ??= EMPTY_STATS();
    s[field] += by;
    await this.store.set("stats", this.stats);
  }
  getStats() {
    return this.stats;
  }
};

// src/background/native.ts
var HOST_NAME = "app.zuko.host";
var RETRY_AFTER_MS = 2e4;
var HEARTBEAT_MS = 25e3;
var MISSED_BEATS = 2;
var NativeLink = class {
  port = null;
  pending = /* @__PURE__ */ new Map();
  nextId = 1;
  connecting = null;
  lastAttempt = 0;
  beatTimer = null;
  missed = 0;
  linked = false;
  /** The app's local-AI status as of the last policy read (null: unknown / older app). */
  localAi = null;
  policyAt = 0;
  appVersion = null;
  lastError = null;
  /** Called after every successful link (the service worker syncs policy and vault here). */
  onLinked = null;
  onChange = null;
  version;
  host;
  heartbeatMs;
  beatTimeoutMs;
  retryAfterMs;
  /** `timing` shortens the heartbeat, its answer deadline and the retry throttle (tests). */
  constructor(version, host = HOST_NAME, timing = {}) {
    this.version = version;
    this.host = host;
    this.heartbeatMs = timing.heartbeatMs ?? HEARTBEAT_MS;
    this.beatTimeoutMs = timing.beatTimeoutMs ?? 5e3;
    this.retryAfterMs = timing.retryAfterMs ?? RETRY_AFTER_MS;
  }
  /**
   * The periodic check (the service worker's alarm calls it too): a linked extension says
   * hello so the app keeps showing it as connected; an unlinked one tries to link again
   * (throttled like every other retry).
   */
  async tick() {
    if (!this.linked) {
      await this.connect();
      return;
    }
    const port = this.port;
    const r = await this.rpc({ op: "hello", version: this.version }, this.beatTimeoutMs);
    if (!this.linked || this.port !== port) return;
    if (r?.ok === true) {
      this.missed = 0;
      if (typeof r.version === "string") this.appVersion = r.version;
      return;
    }
    if (r !== null || ++this.missed >= MISSED_BEATS) {
      if (typeof r?.error === "string") this.lastError = r.error;
      this.disconnect();
    }
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.missed = 0;
    const timer = setInterval(() => void this.tick(), this.heartbeatMs);
    timer.unref?.();
    this.beatTimer = timer;
  }
  stopHeartbeat() {
    if (this.beatTimer !== null) clearInterval(this.beatTimer);
    this.beatTimer = null;
  }
  /**
   * Connects if not linked. Throttled: a missing host is retried at most every 20 s unless
   * `force` (the heartbeat alarm in sw.ts fires every 30 s, so each one gets its attempt).
   */
  connect(force = false) {
    if (this.linked) return Promise.resolve(true);
    if (this.connecting) return this.connecting;
    if (!force && Date.now() - this.lastAttempt < this.retryAfterMs) return Promise.resolve(false);
    this.lastAttempt = Date.now();
    this.connecting = this.doConnect().finally(() => {
      this.connecting = null;
    });
    return this.connecting;
  }
  /** Fire-and-forget retry used on hot paths. */
  maybeReconnect() {
    if (!this.linked && !this.connecting && Date.now() - this.lastAttempt >= this.retryAfterMs) void this.connect();
  }
  async doConnect() {
    let port;
    try {
      port = chrome.runtime.connectNative(this.host);
    } catch (e) {
      this.lastError = e instanceof Error ? e.message : String(e);
      return false;
    }
    this.port = port;
    port.onMessage.addListener((m) => this.onMessage(m));
    port.onDisconnect.addListener(() => this.onDisconnect(port));
    const hello = await this.rpc({ op: "hello", version: this.version }, 2500);
    if (hello?.ok === true) {
      this.linked = true;
      this.appVersion = typeof hello.version === "string" ? hello.version : null;
      this.lastError = null;
      this.startHeartbeat();
      this.onChange?.();
      try {
        await this.onLinked?.();
      } catch (e) {
        console.warn("[Zuko] syncing with the desktop app failed:", e);
      }
      return true;
    }
    if (!this.lastError) this.lastError = typeof hello?.error === "string" ? hello.error : "the desktop app did not answer";
    try {
      port.disconnect();
    } catch {
    }
    this.cleanup(port);
    return false;
  }
  onMessage(m) {
    const id = typeof m?.id === "number" ? m.id : null;
    if (id === null) return;
    const p = this.pending.get(id);
    if (!p) return;
    clearTimeout(p.timer);
    this.pending.delete(id);
    p.resolve(m);
  }
  onDisconnect(port) {
    const err = chrome.runtime.lastError?.message;
    if (err) this.lastError = err;
    this.cleanup(port);
  }
  cleanup(port) {
    if (this.port !== port) return;
    this.port = null;
    this.stopHeartbeat();
    const wasLinked = this.linked;
    this.linked = false;
    this.localAi = null;
    for (const p of this.pending.values()) {
      clearTimeout(p.timer);
      p.resolve(null);
    }
    this.pending.clear();
    if (wasLinked) this.onChange?.();
  }
  /** One request, one reply (or null on timeout / disconnect). */
  rpc(msg, timeoutMs = 5e3) {
    const port = this.port;
    if (!port) return Promise.resolve(null);
    const id = this.nextId++;
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        resolve(null);
      }, timeoutMs);
      this.pending.set(id, { resolve, timer });
      try {
        port.postMessage({ ...msg, id });
      } catch {
        clearTimeout(timer);
        this.pending.delete(id);
        resolve(null);
      }
    });
  }
  async request(msg, timeoutMs) {
    if (!this.linked) return null;
    const r = await this.rpc(msg, timeoutMs);
    return r?.ok === true ? r : null;
  }
  async mask(text, site) {
    const r = await this.request({ op: "mask", text, site }, 2e4);
    if (!r || typeof r.text !== "string" || !r.report) return null;
    return { text: r.text, report: r.report };
  }
  async fetchVault() {
    const r = await this.request({ op: "vault" }, 8e3);
    if (!r) return null;
    let v = r.vault;
    if (typeof v === "string") {
      try {
        v = JSON.parse(v);
      } catch {
        return null;
      }
    }
    if (!v || typeof v !== "object") return null;
    return { entries: Array.isArray(v.entries) ? v.entries : [], counters: v.counters ?? {} };
  }
  async fetchPolicy() {
    const r = await this.request({ op: "policy" }, 6e3);
    this.policyAt = Date.now();
    if (r) {
      const a = r.localAi;
      this.localAi = a && typeof a === "object" ? {
        enabled: a.enabled === true,
        reachable: a.reachable === true,
        model: typeof a.model === "string" ? a.model : "",
        waitForPromptScan: a.waitForPromptScan === true
      } : null;
    }
    return r && r.detector && typeof r.detector === "object" ? r.detector : null;
  }
  /** Re-reads the app's local-AI status when the last read is older than `maxAgeMs`. */
  async refreshLocalAi(maxAgeMs = 3e4) {
    if (!this.linked || Date.now() - this.policyAt < maxAgeMs) return;
    this.policyAt = Date.now();
    await this.fetchPolicy();
  }
  async deepScan(text, site, wait) {
    const r = await this.request({ op: "deepScan", text, site, wait }, wait ? 44e3 : 6e3);
    if (!r) return null;
    if (r.enabled !== true) {
      if (this.localAi) this.localAi = { ...this.localAi, enabled: false };
      return { enabled: false, added: [], vault: null };
    }
    let v = r.vault;
    if (typeof v === "string") {
      try {
        v = JSON.parse(v);
      } catch {
        v = null;
      }
    }
    const vault = v && typeof v === "object" ? { entries: Array.isArray(v.entries) ? v.entries : [], counters: v.counters ?? {} } : null;
    const added = Array.isArray(r.added) ? r.added.filter((a) => a && typeof a.key === "string").map((a) => ({ key: a.key, label: String(a.label ?? "") })) : [];
    return { enabled: true, added, vault };
  }
  event(e) {
    if (!this.linked || !this.port) return;
    void this.rpc({ op: "event", ...e }, 3e3);
  }
  disconnect() {
    const port = this.port;
    if (!port) return;
    try {
      port.disconnect();
    } catch {
    }
    this.cleanup(port);
  }
};

// src/shared/protocol.ts
var DEFAULT_PREFS = { sites: { chatgpt: true, claude: true, deepseek: true } };
var STORAGE_PREFS = "zuko.prefs";
var STORAGE_SYNC = "zuko.sync";

// src/shared/sites.ts
var SITE_IDS = ["chatgpt", "claude", "deepseek"];
var HOSTS = {
  "chatgpt.com": "chatgpt",
  "chat.openai.com": "chatgpt",
  "claude.ai": "claude",
  "chat.deepseek.com": "deepseek"
};
function siteForHost(host) {
  return HOSTS[host.toLowerCase()] ?? null;
}

// src/background/sw.ts
var sessionStore = {
  async get(key) {
    return (await chrome.storage.session.get(`zuko.${key}`))[`zuko.${key}`];
  },
  async set(key, value) {
    if (value === void 0) await chrome.storage.session.remove(`zuko.${key}`);
    else await chrome.storage.session.set({ [`zuko.${key}`]: value });
  }
};
var brain = new Brain(sessionStore);
var link = new NativeLink(chrome.runtime.getManifest().version);
brain.link = link;
var syncRev = 0;
var prefs = structuredClone(DEFAULT_PREFS);
async function publishSync() {
  const state = { rev: ++syncRev, vaultSize: brain.vaultSize(), engine: brain.engineLoaded, linked: link.linked };
  await chrome.storage.local.set({ [STORAGE_SYNC]: state });
}
async function loadPrefs() {
  const stored = (await chrome.storage.local.get(STORAGE_PREFS))[STORAGE_PREFS];
  prefs = { sites: { ...DEFAULT_PREFS.sites, ...stored?.sites ?? {} } };
}
async function loadEngine() {
  try {
    const res = await fetch(chrome.runtime.getURL("zuko_core.wasm"));
    if (!res.ok) throw new Error(`zuko_core.wasm is missing from the extension (HTTP ${res.status})`);
    const engine = new Engine(await WasmEngine.load(await res.arrayBuffer()));
    await brain.attach(engine);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(
      "[Zuko] ENGINE NOT LOADED: " + msg + "\nBuild it with `cargo build -p zuko-core --target wasm32-unknown-unknown --release` in app/, then `npm run build` in extension/. Until then Zuko BLOCKS requests that contain obvious secrets and cannot mask anything else."
    );
    await brain.attach(null, msg);
  }
}
var linking = Promise.resolve(false);
link.onChange = () => void publishSync();
link.onLinked = async () => {
  if (!brain.engineLoaded) return;
  const detector = await link.fetchPolicy();
  if (detector) await brain.applyDetector(detector);
  const vault = await link.fetchVault();
  if (vault) await brain.adoptRemoteVault(vault);
  await publishSync();
};
var ready = (async () => {
  await loadPrefs();
  await loadEngine();
  linking = link.connect(true);
  await publishSync();
})();
var isExtensionPage = (s) => s.id === chrome.runtime.id && typeof s.url === "string" && s.url.startsWith(chrome.runtime.getURL(""));
var isContentScript = (s) => {
  if (s.id !== chrome.runtime.id || !s.tab || typeof s.url !== "string") return false;
  try {
    return siteForHost(new URL(s.url).hostname) !== null;
  } catch {
    return false;
  }
};
var safeSite = (v) => SITE_IDS.includes(v) ? v : "chatgpt";
async function report(site, kind, count, keys, viaApp = false) {
  if (kind === "masked") await brain.bump(site, "masked", count);
  else if (kind === "blocked") await brain.bump(site, "blocked", Math.max(1, count));
  else await brain.bump(site, "uploads", 1);
  if (!viaApp) link.event({ kind, site, count, keys });
}
function aiToast(tabId, n) {
  void publishSync();
  if (tabId === void 0 || n <= 0) return;
  const text = `AI deep scan: +${n} ${n === 1 ? "item" : "items"}`;
  void chrome.tabs.sendMessage(tabId, { type: "toast", level: "info", text }, { frameId: 0 }).catch(() => void 0);
}
var offscreenOpen = null;
async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length > 0) return;
  offscreenOpen ??= chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["WORKERS"],
    justification: "Extract text from PDFs locally with pdf.js so they can be sanitized before upload"
  }).catch((e) => {
    if (!String(e?.message ?? e).includes("single offscreen")) throw e;
  }).finally(() => {
    offscreenOpen = null;
  });
  await offscreenOpen;
}
async function sanitizePdf(site, base64, tabId) {
  await ensureOffscreen();
  const r = await chrome.runtime.sendMessage({ target: "offscreen", type: "pdf-extract", base64 });
  if (!r || !r.ok) return { ok: false, error: r?.error ?? "the PDF reader did not answer" };
  if (!r.hasText) return { ok: true, blocked: true, pages: r.pages, warnings: r.warnings };
  link.maybeReconnect();
  const masked = await brain.maskMany([r.markdown], { site, mode: "full", source: "file", onAiAdded: (n) => aiToast(tabId, n) });
  await report(site, "masked", masked.count, masked.keys, masked.via === "app");
  await publishSync();
  return { ok: true, blocked: false, markdown: masked.texts[0], pages: r.pages, warnings: r.warnings, count: masked.count, keys: masked.keys };
}
async function status() {
  await Promise.race([linking, new Promise((r) => setTimeout(r, 3e3))]);
  await link.refreshLocalAi(5e3).catch(() => void 0);
  const stats = brain.getStats();
  const total = { masked: 0, blocked: 0, uploads: 0, restored: 0 };
  for (const s of Object.values(stats)) {
    total.masked += s.masked;
    total.blocked += s.blocked;
    total.uploads += s.uploads;
    total.restored += s.restored;
  }
  return {
    ok: true,
    version: chrome.runtime.getManifest().version,
    engine: brain.engineLoaded,
    engineError: brain.engineError,
    linked: link.linked,
    appVersion: link.appVersion,
    localAi: link.linked ? link.localAi : null,
    linkError: link.lastError,
    vaultSize: brain.vaultSize(),
    prefs,
    stats,
    total
  };
}
async function handle(msg, sender) {
  await ready;
  const fromPage = isContentScript(sender);
  const fromUi = isExtensionPage(sender);
  if (!fromPage && !fromUi) return { ok: false, error: "unauthorized sender" };
  switch (msg.type) {
    case "maskMany": {
      if (!fromPage) break;
      await Promise.race([linking, new Promise((r2) => setTimeout(r2, 1500))]);
      link.maybeReconnect();
      void link.refreshLocalAi().catch(() => void 0);
      const site = safeSite(msg.site);
      const tabId = sender.tab?.id;
      const r = await brain.maskMany(msg.texts, { site, mode: msg.mode, source: msg.source, onAiAdded: (n) => aiToast(tabId, n) });
      if (msg.mode === "full") {
        await report(site, "masked", r.count, r.keys, r.via === "app");
        if (r.newKeys.length > 0) await publishSync();
      }
      return { ok: true, ...r };
    }
    case "tripwire": {
      if (!fromPage) break;
      const site = safeSite(msg.site);
      const r = brain.tripwire(msg.texts);
      if (r.action === "masked") {
        await report(site, "masked", r.count, r.keys);
      } else if (r.action === "block") {
        await report(site, "blocked", 1, r.keys);
      }
      return { ok: true, ...r };
    }
    case "rehydrate":
      return { ok: true, ...brain.rehydrate(msg.texts) };
    case "resolve":
      return { ok: true, values: brain.resolve(msg.keys) };
    case "known":
      return { ok: true, keys: brain.knownKeys() };
    case "scan":
      return { ok: true, ...brain.scan(msg.text) };
    case "event": {
      if (!fromPage) break;
      const site = safeSite(msg.site);
      if (msg.kind === "restored") await brain.bump(site, "restored", msg.count);
      else await report(site, msg.kind, msg.count, msg.keys);
      return { ok: true };
    }
    case "toast": {
      const tabId = sender.tab?.id;
      if (!fromPage || tabId === void 0) break;
      await chrome.tabs.sendMessage(tabId, { type: "toast", level: msg.level, text: msg.text }, { frameId: 0 }).catch(() => void 0);
      return { ok: true };
    }
    case "sanitize-pdf":
      if (!fromPage) break;
      return sanitizePdf(safeSite(msg.site), msg.base64, sender.tab?.id);
    case "state": {
      const site = safeSite(msg.site);
      return { ok: true, enabled: prefs.sites[site] !== false, engine: brain.engineLoaded, linked: link.linked, vaultSize: brain.vaultSize() };
    }
    case "status":
      if (!fromUi) break;
      return status();
    case "setSite": {
      if (!fromUi) break;
      const site = safeSite(msg.site);
      prefs = { sites: { ...prefs.sites, [site]: msg.enabled === true } };
      await chrome.storage.local.set({ [STORAGE_PREFS]: prefs });
      return { ok: true, prefs };
    }
    case "clearVault": {
      if (!fromUi) break;
      await brain.clearVault();
      await publishSync();
      return { ok: true };
    }
    case "relink": {
      if (!fromUi) break;
      const ok = await link.connect(true);
      await publishSync();
      return { ok: true, linked: ok, error: link.lastError };
    }
  }
  return { ok: false, error: "unauthorized or unknown request" };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object" || message.target === "offscreen") return false;
  handle(message, sender).then(sendResponse, (e) => {
    const unavailable = e instanceof EngineUnavailable;
    if (!unavailable) console.error("[Zuko] request failed:", e);
    sendResponse({ ok: false, error: unavailable ? "engine-unavailable" : e instanceof Error ? e.message : String(e) });
  });
  return true;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[STORAGE_PREFS]?.newValue) prefs = changes[STORAGE_PREFS].newValue;
});
chrome.runtime.onStartup.addListener(() => void ready);
chrome.runtime.onInstalled.addListener(() => void ready);
var HEARTBEAT_ALARM = "zuko-heartbeat";
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== HEARTBEAT_ALARM) return;
  void ready.then(() => link.tick()).then(() => publishSync());
});
void chrome.alarms.get(HEARTBEAT_ALARM).then(async (existing) => {
  if (!existing) await chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 0.5 });
}).catch((e) => console.warn("[Zuko] heartbeat alarm unavailable:", e));
