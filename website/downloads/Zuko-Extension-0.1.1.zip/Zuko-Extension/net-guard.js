"use strict";
(() => {
  // src/shared/sites.ts
  var HOSTS = {
    "chatgpt.com": "chatgpt",
    "chat.openai.com": "chatgpt",
    "claude.ai": "claude",
    "chat.deepseek.com": "deepseek"
  };
  function siteForHost(host) {
    return HOSTS[host.toLowerCase()] ?? null;
  }
  var ENDPOINTS = {
    chatgpt: {
      // /backend-api/conversation, /backend-api/f/conversation, /backend-anon/f/conversation,
      // and the .../prepare call that runs first.
      prompt: [/^\/(?:backend-api|backend-anon)\/(?:f\/)?conversation(?:\/prepare)?\/?$/],
      upload: [
        (u, m) => m !== "GET" && /^\/backend-api\/files(?:\/|$)/.test(u.pathname),
        // Blob storage PUT after /backend-api/files hands out an upload URL.
        (u, m) => m === "PUT" && /(?:^|\.)(?:blob\.core\.windows\.net|oaiusercontent\.com|openaiusercontent\.com)$/.test(u.hostname)
      ]
    },
    claude: {
      prompt: [/^\/api\/organizations\/[^/]+\/chat_conversations\/[^/]+\/(?:completion|retry_completion)\/?$/],
      upload: [
        (u, m) => m !== "GET" && /^\/api\/(?:organizations\/[^/]+\/)?(?:upload|convert_document)\/?$/.test(u.pathname),
        (u, m) => m !== "GET" && /^\/api\/organizations\/[^/]+\/(?:upload|files|convert_document)(?:\/|$)/.test(u.pathname)
      ]
    },
    deepseek: {
      prompt: [/^\/api\/v0\/chat\/(?:completion|edit_message)\/?$/],
      upload: [(u, m) => m !== "GET" && /^\/api\/v0\/file\/upload_file\/?$/.test(u.pathname)]
    }
  };
  function isPromptEndpoint(site2, url, method) {
    return method !== "GET" && method !== "HEAD" && ENDPOINTS[site2].prompt.some((re) => re.test(url.pathname));
  }
  function isUploadEndpoint(site2, url, method) {
    return ENDPOINTS[site2].upload.some((f) => f(url, method.toUpperCase()));
  }

  // src/main-world/bridge.ts
  var PORT_TAG = "port";
  var READY_EVENT = "zuko:main-ready";
  var BridgeUnavailable = class extends Error {
    constructor(message = "bridge unavailable") {
      super(message);
    }
  };
  var DEFAULT_TIMEOUT_MS = 8e3;
  function createPageBridge(win) {
    let port = null;
    let nextId = 1;
    const pending = /* @__PURE__ */ new Map();
    const waiting = [];
    const stateListeners = [];
    const bridge = {
      // Until the first state arrives we assume protection is on and the vault may be non-empty.
      state: { type: "state", enabled: true, vaultSize: 0, engine: true, known: false },
      request(msg, timeoutMs = DEFAULT_TIMEOUT_MS) {
        return new Promise((resolve, reject) => {
          const id = nextId++;
          const timer = setTimeout(() => {
            pending.delete(id);
            reject(new BridgeUnavailable("timed out"));
          }, timeoutMs);
          pending.set(id, { resolve, reject, timer });
          const send = () => port?.postMessage({ ...msg, id });
          if (port) send();
          else waiting.push(send);
        });
      },
      post(msg) {
        if (!port) return false;
        port.postMessage(msg);
        return true;
      },
      connected: () => port !== null,
      onState: (cb) => void stateListeners.push(cb)
    };
    const onPortMessage = (e) => {
      const m = e.data;
      if (!m || typeof m !== "object") return;
      if (m.type === "state") {
        const s = m;
        bridge.state = { ...s, known: true };
        stateListeners.forEach((cb) => cb());
        return;
      }
      const reply = m;
      const p = pending.get(reply.id);
      if (!p) return;
      clearTimeout(p.timer);
      pending.delete(reply.id);
      if (reply.ok) p.resolve(reply);
      else p.reject(new BridgeUnavailable(String(reply.error ?? "request failed")));
    };
    const onWindowMessage = (e) => {
      const d = e.data;
      if (port || e.source !== win || !d || typeof d !== "object" || d.__zuko !== PORT_TAG || !e.ports[0]) return;
      e.stopImmediatePropagation();
      port = e.ports[0];
      port.onmessage = onPortMessage;
      win.removeEventListener("message", onWindowMessage, true);
      port.postMessage({ type: "hello" });
      waiting.splice(0).forEach((send) => send());
    };
    win.addEventListener("message", onWindowMessage, true);
    win.dispatchEvent(new win.CustomEvent(READY_EVENT));
    return bridge;
  }

  // src/shared/files.ts
  var TEXT_EXT = /\.(txt|md|markdown|json|jsonl|ndjson|csv|tsv|log|xml|ya?ml|toml|ini|env|cfg|conf|properties|html?|css|scss|less|svg|[cm]?[jt]sx?|vue|svelte|py|rb|go|rs|java|kt|kts|scala|c|h|cc|cpp|hpp|cs|php|sh|bash|zsh|ps1|psm1|bat|cmd|sql|swift|dart|lua|r|pl|ex|exs|tf|gradle)$/i;
  var TEXT_TYPE = /^text\/|json|xml|javascript|ecmascript|csv|markdown|yaml|toml|x-www-form-urlencoded|x-sh\b|x-python|x-ruby|x-rust|x-go|x-java/i;
  function isTextLikeName(name) {
    return TEXT_EXT.test(name);
  }
  function isTextLikeType(type) {
    return TEXT_TYPE.test(type);
  }
  var MAX_SCAN_BYTES = 16 * 1024 * 1024;

  // src/main-world/fallback.ts
  var RULES = [
    ["private key", /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----/],
    ["Anthropic API key", /\bsk-ant-[A-Za-z0-9_-]{20,}/],
    ["OpenAI API key", /\bsk-(?:proj-|svcacct-|admin-)?[A-Za-z0-9_-]{32,}/],
    ["Stripe key", /\b[rs]k_(?:live|test)_[0-9A-Za-z]{20,}/],
    ["AWS access key", /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/],
    ["GitHub token", /\b(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{50,})/],
    ["GitLab token", /\bglpat-[A-Za-z0-9_-]{20,}/],
    ["Slack token", /\bxox[abprs]-[A-Za-z0-9-]{10,}/],
    ["Google API key", /\bAIza[0-9A-Za-z_-]{35}\b/],
    ["npm token", /\bnpm_[A-Za-z0-9]{36}\b/],
    ["Hugging Face token", /\bhf_[A-Za-z0-9]{34,}\b/],
    ["JSON web token", /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/]
  ];
  function findHighConfidenceSecret(text) {
    for (const [label, re] of RULES) if (re.test(text)) return label;
    return null;
  }

  // src/shared/placeholders.ts
  var NOTE_PREFIX = "[Zuko privacy note:";
  function wrap(key) {
    return `{{${key}}}`;
  }
  function buildNote(keys) {
    const uniq = [...new Set(keys)];
    const shown = uniq.slice(0, 6).map(wrap).join(", ") + (uniq.length > 6 ? ", ..." : "");
    const verb = uniq.length === 1 ? "is a placeholder" : "are placeholders";
    return `${NOTE_PREFIX} ${shown} ${verb} for private values kept on the user's machine. Use ${uniq.length === 1 ? "it" : "them"} verbatim, exactly as written, and never ask for or guess the real values.]`;
  }
  var NOTE_AT_START = /^\s*\[Zuko privacy note:[^\]]*\]\s*/;
  function stripNote(text) {
    return text.replace(NOTE_AT_START, "");
  }
  function withNote(text, keys) {
    if (keys.length === 0) return text;
    return `${buildNote(keys)}

${stripNote(text)}`;
  }

  // src/main-world/rewriters.ts
  var isObj = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  function stringField(holder, key) {
    const v = holder[key];
    if (typeof v !== "string") return null;
    const field = {
      text: v,
      set(value) {
        holder[key] = value;
        field.text = value;
      }
    };
    return field;
  }
  var chatgpt = {
    fields(body) {
      const out = [];
      if (!isObj(body) || !Array.isArray(body.messages)) return out;
      for (const m of body.messages) {
        const content = isObj(m) ? m.content : null;
        if (!isObj(content)) continue;
        if (Array.isArray(content.parts)) {
          content.parts.forEach((part, i) => {
            if (typeof part === "string") {
              const f = stringField(content.parts, i);
              if (f) out.push(f);
            } else if (isObj(part)) {
              const f = stringField(part, "text");
              if (f) out.push(f);
            }
          });
        }
        const t = stringField(content, "text");
        if (t) out.push(t);
      }
      return out;
    },
    noteField(body, fields) {
      if (!isObj(body) || !Array.isArray(body.messages)) return null;
      for (let i = body.messages.length - 1; i >= 0; i--) {
        const m = body.messages[i];
        if (!isObj(m) || (m.author?.role ?? "user") !== "user" || !isObj(m.content)) continue;
        if (Array.isArray(m.content.parts)) {
          const idx = m.content.parts.findIndex((p) => typeof p === "string");
          if (idx >= 0) return stringField(m.content.parts, idx);
        }
        const t = stringField(m.content, "text");
        if (t) return t;
      }
      return fields[0] ?? null;
    }
  };
  var claude = {
    fields(body) {
      const out = [];
      if (!isObj(body)) return out;
      const p = stringField(body, "prompt");
      if (p) out.push(p);
      if (Array.isArray(body.attachments)) {
        for (const a of body.attachments) {
          if (!isObj(a)) continue;
          const f = stringField(a, "extracted_content");
          if (f) out.push(f);
        }
      }
      return out;
    },
    noteField(body) {
      return isObj(body) ? stringField(body, "prompt") : null;
    }
  };
  var deepseek = {
    fields(body) {
      const f = isObj(body) ? stringField(body, "prompt") : null;
      return f ? [f] : [];
    },
    noteField(body) {
      return isObj(body) ? stringField(body, "prompt") : null;
    }
  };
  var REWRITERS = { chatgpt, claude, deepseek };
  function rewriterFor(site2) {
    return REWRITERS[site2];
  }
  async function rewriteJson(site2, raw, mask) {
    let body;
    try {
      body = JSON.parse(raw);
    } catch {
      return null;
    }
    const rw = rewriterFor(site2);
    const fields = rw.fields(body);
    if (fields.length === 0) return null;
    const outcome = await mask(fields.map((f) => f.text));
    if (outcome.texts.length !== fields.length) throw new Error("mask returned the wrong number of texts");
    let changed = false;
    fields.forEach((f, i) => {
      const next = outcome.texts[i];
      if (next !== f.text) {
        f.set(next);
        changed = true;
      }
    });
    if (outcome.keys.length > 0) {
      const target = rw.noteField(body, fields);
      if (target) {
        const noted = withNote(target.text, outcome.keys);
        if (noted !== target.text) {
          target.set(noted);
          changed = true;
        }
      } else if (site2 !== "chatgpt" && isObj(body) && (body.prompt === void 0 || body.prompt === "")) {
        body.prompt = withNote("", outcome.keys).trim();
        changed = true;
      }
    }
    return { body: changed ? JSON.stringify(body) : raw, count: outcome.count, keys: outcome.keys, changed };
  }

  // src/main-world/pipeline.ts
  var PASS = { action: "pass" };
  var Pipeline = class {
    win;
    site;
    bridge;
    /** Tells the user something (toast, or a minimal banner when the content script is gone). */
    notify;
    constructor(win, site2, bridge, notify) {
      this.win = win;
      this.site = site2;
      this.bridge = bridge;
      this.notify = notify ?? ((level, text) => void bridge.post({ type: "notify", level, text }));
    }
    // ---- cheap synchronous decisions (the wrappers use these to stay out of the way) ------
    vaultMayHaveValues() {
      const s = this.bridge.state;
      return !s.known || s.vaultSize > 0;
    }
    parse(url) {
      try {
        const u = new URL(url, this.win.location.href);
        return u.protocol === "http:" || u.protocol === "https:" ? u : null;
      } catch {
        return null;
      }
    }
    /** True when a request needs the async guard at all. */
    needsGuard(url, method, body) {
      if (!this.bridge.state.enabled) return false;
      const u = this.parse(url);
      if (!u) return false;
      const m = method.toUpperCase();
      const hasBody = body !== null && body !== void 0 && m !== "GET" && m !== "HEAD";
      if (hasBody && (isPromptEndpoint(this.site, u, m) || isUploadEndpoint(this.site, u, m))) return true;
      if (!this.vaultMayHaveValues()) return false;
      if (hasBody) return true;
      return u.origin !== this.win.location.origin && u.search !== "";
    }
    // ---- the guard ------------------------------------------------------------------------
    async guard(req) {
      if (!this.bridge.state.enabled) return PASS;
      const url = this.parse(req.url);
      if (!url) return PASS;
      const method = req.method.toUpperCase();
      const ctx = {
        site: this.site,
        known: isPromptEndpoint(this.site, url, method),
        upload: isUploadEndpoint(this.site, url, method),
        url,
        contentType: (req.contentType ?? "").toLowerCase()
      };
      if (url.origin !== this.win.location.origin && url.search !== "" && this.vaultMayHaveValues()) {
        const r = await this.tripwire([url.href, safeDecode(url.href)]);
        if (r?.action === "block") return this.block(r.reason, url);
        if (r?.action === "masked") return this.block("a protected value is in the request URL", url);
      }
      const hasBody = req.body !== null && req.body !== void 0 && method !== "GET" && method !== "HEAD";
      if (!hasBody) return PASS;
      if (!ctx.known && !ctx.upload && !this.vaultMayHaveValues()) return PASS;
      return this.processBody(req.body, ctx);
    }
    async processBody(body, ctx) {
      const w2 = this.win;
      if (typeof body === "string") return this.processString(body, ctx, (s) => s);
      if (body instanceof w2.URLSearchParams) return this.processForm(body, ctx);
      if (body instanceof w2.FormData) return this.processFormData(body, ctx);
      if (body instanceof w2.Blob) return this.processBlob(body, ctx);
      if (body instanceof w2.ArrayBuffer || ArrayBuffer.isView(body)) {
        const bytes = body instanceof w2.ArrayBuffer ? new Uint8Array(body) : new Uint8Array(body.buffer, body.byteOffset, body.byteLength);
        if (bytes.byteLength > MAX_SCAN_BYTES) return PASS;
        let text;
        try {
          text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
        } catch {
          return PASS;
        }
        return this.processString(text, ctx, (s) => new TextEncoder().encode(s));
      }
      return PASS;
    }
    // ---- text bodies ----------------------------------------------------------------------
    async processString(text, ctx, wrap2) {
      if (text.length > MAX_SCAN_BYTES) return PASS;
      let cur = text;
      let count = 0;
      if (ctx.known) {
        let rewritten = false;
        try {
          const rw = await rewriteJson(this.site, cur, (texts) => this.maskFields(texts, "full"));
          if (rw) {
            rewritten = true;
            cur = rw.body;
            count += rw.count;
          }
        } catch {
          return this.failSafe(text, ctx);
        }
        if (!rewritten && !ctx.contentType.includes("json") && !looksLikeJson(text)) {
          try {
            const m = await this.maskFields([cur], "full");
            cur = m.texts[0];
            count += m.count;
          } catch {
            return this.failSafe(text, ctx);
          }
        }
      } else if (ctx.upload && isTextUpload(ctx)) {
        try {
          const m = await this.maskFields([cur], "full", "file");
          cur = m.texts[0];
          count += m.count;
        } catch {
          return this.failSafe(text, ctx);
        }
      }
      if (this.vaultMayHaveValues() || count > 0) {
        const t = await this.tripwire([cur]);
        if (t?.action === "block") return this.block(t.reason, ctx.url);
        if (t?.action === "masked") {
          cur = t.texts[0];
          count += t.count;
        }
      }
      return cur === text ? PASS : { action: "replace", body: wrap2(cur) };
    }
    async processForm(params, ctx) {
      if (!this.vaultMayHaveValues()) return PASS;
      const entries = [...params.entries()];
      const texts = entries.flatMap(([k, v]) => [k, v]);
      const t = await this.tripwire(texts);
      if (t?.action === "block") return this.block(t.reason, ctx.url);
      if (t?.action !== "masked") return PASS;
      const next = new this.win.URLSearchParams();
      for (let i = 0; i < entries.length; i++) next.append(t.texts[i * 2], t.texts[i * 2 + 1]);
      return { action: "replace", body: next };
    }
    async processFormData(fd, ctx) {
      const w2 = this.win;
      const entries = [...fd.entries()];
      const next = entries.map(([k, v]) => [k, v]);
      let changed = false;
      const strIdx = entries.flatMap(([, v], i) => typeof v === "string" ? [i] : []);
      if (strIdx.length > 0 && this.vaultMayHaveValues()) {
        const t = await this.tripwire(strIdx.map((i) => entries[i][1]));
        if (t?.action === "block") return this.block(t.reason, ctx.url);
        if (t?.action === "masked") {
          strIdx.forEach((i, j) => next[i] = [entries[i][0], t.texts[j]]);
          changed = true;
        }
      }
      for (let i = 0; i < entries.length; i++) {
        const v = entries[i][1];
        if (typeof v === "string" || !isTextBlob(v)) continue;
        const out = await this.processBlob(v, ctx);
        if (out.action === "block") return out;
        if (out.action === "replace") {
          next[i] = [entries[i][0], out.body];
          changed = true;
        }
      }
      if (!changed) return PASS;
      const rebuilt = new w2.FormData();
      for (const [k, v] of next) {
        if (typeof v === "string") rebuilt.append(k, v);
        else rebuilt.append(k, v, v.name ?? "blob");
      }
      return { action: "replace", body: rebuilt };
    }
    async processBlob(blob, ctx) {
      if (blob.size > MAX_SCAN_BYTES || !isTextBlob(blob)) return PASS;
      let text;
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(await blob.arrayBuffer());
      } catch {
        return PASS;
      }
      const w2 = this.win;
      const file = blob;
      return this.processString(
        text,
        ctx,
        (s) => typeof file.name === "string" ? new w2.File([s], file.name, { type: blob.type, lastModified: file.lastModified }) : new w2.Blob([s], { type: blob.type })
      );
    }
    // ---- bridge calls ---------------------------------------------------------------------
    async maskFields(texts, mode, source) {
      const r = await this.bridge.request({ type: "maskMany", texts, mode, source });
      if (r.keys.length > 0 || r.count > 0) this.bridge.state.vaultSize = Math.max(this.bridge.state.vaultSize, 1);
      return { texts: r.texts, keys: r.keys, count: r.count };
    }
    /** The tripwire; null when the engine cannot be reached (the caller then lets the request through). */
    async tripwire(texts) {
      try {
        return await this.bridge.request({ type: "tripwire", texts });
      } catch (e) {
        if (e instanceof BridgeUnavailable) return null;
        throw e;
      }
    }
    // ---- outcomes -------------------------------------------------------------------------
    block(reason, url) {
      const where = url.hostname === this.win.location.hostname ? "this site" : url.hostname;
      this.notify("error", `Zuko blocked a request to ${where}: ${reason}.`);
      return { action: "block", reason };
    }
    /** Engine unreachable: block only what is obviously a live credential. */
    failSafe(raw, ctx) {
      const texts = [];
      try {
        const body = JSON.parse(raw);
        for (const f of rewriterFor(this.site).fields(body)) texts.push(f.text);
      } catch {
        texts.push(raw);
      }
      for (const t of texts) {
        const label = findHighConfidenceSecret(t);
        if (label) {
          this.bridge.post({ type: "event", kind: "blocked", count: 1, keys: [] });
          return this.block(
            `the Zuko engine is not available and this message contains what looks like a ${label}. Nothing was sent. Reload the extension or the page and try again`,
            ctx.url
          );
        }
      }
      return PASS;
    }
  };
  function safeDecode(s) {
    try {
      return decodeURIComponent(s.replace(/\+/g, " "));
    } catch {
      return s;
    }
  }
  function looksLikeJson(s) {
    const t = s.trimStart();
    return t.startsWith("{") || t.startsWith("[");
  }
  function isTextBlob(b) {
    const name = b.name;
    return isTextLikeType(b.type) || typeof name === "string" && isTextLikeName(name) || b.type === "" && b.size <= 2 * 1024 * 1024;
  }
  function isTextUpload(ctx) {
    return ctx.contentType === "" || isTextLikeType(ctx.contentType) || ctx.contentType.includes("octet-stream");
  }

  // src/main-world/guard-core.ts
  function installNetGuard(win, site2, bridge = createPageBridge(win)) {
    const undo = [];
    const patch = (target, key, make) => {
      if (!target || typeof target[key] !== "function") return;
      const orig = target[key];
      const wrapped = make(orig);
      try {
        Object.defineProperty(wrapped, "name", { value: orig.name });
        Object.defineProperty(wrapped, "length", { value: orig.length });
      } catch {
      }
      target[key] = wrapped;
      undo.push(() => {
        target[key] = orig;
      });
    };
    const notify = (level, text) => {
      if (!bridge.post({ type: "notify", level, text })) fallbackBanner(win, text);
    };
    const pipeline = new Pipeline(win, site2, bridge, notify);
    const blockedError = (reason) => new win.TypeError(`Zuko blocked this request: ${reason}`);
    patch(win, "fetch", (origFetch) => {
      const call = (input, init) => origFetch.call(win, input, init);
      async function guarded(input, init, method, url) {
        const req = input instanceof win.Request ? input : null;
        let body = init?.body;
        let contentType = headerOf(init?.headers ?? req?.headers, "content-type");
        try {
          if (body === void 0 && req && req.body !== null && method !== "GET" && method !== "HEAD") {
            body = await req.clone().arrayBuffer();
            contentType ??= req.headers.get("content-type");
          }
          const out = await pipeline.guard({ url, method, body, contentType });
          if (out.action === "block") throw blockedError(out.reason);
          if (out.action === "replace") {
            if (req && init?.body === void 0) return origFetch.call(win, new win.Request(req, { body: out.body }));
            return origFetch.call(win, input, { ...init, body: out.body });
          }
        } catch (e) {
          if (e instanceof win.TypeError && String(e.message).startsWith("Zuko blocked")) throw e;
          console.warn("[Zuko] guard error, request sent unchanged:", e);
        }
        return call(input, init);
      }
      return function zukoFetch(input, init) {
        try {
          const req = input instanceof win.Request ? input : null;
          const method = String(init?.method ?? req?.method ?? "GET").toUpperCase();
          const url = req ? req.url : String(input instanceof win.URL ? input.href : input);
          const hasBody = init?.body !== void 0 ? init.body !== null : req ? req.body !== null : false;
          if (pipeline.needsGuard(url, method, hasBody ? init?.body ?? req : null)) return guarded(input, init, method, url);
        } catch (e) {
          console.warn("[Zuko] guard error, request sent unchanged:", e);
        }
        return call(input, init);
      };
    });
    const xhrMeta = /* @__PURE__ */ new WeakMap();
    const XHR = win.XMLHttpRequest?.prototype;
    patch(XHR, "open", (orig) => function open(method, url, ...rest) {
      xhrMeta.set(this, { method: String(method), url: String(url), contentType: null, pending: false, cancelled: false });
      return orig.call(this, method, url, ...rest);
    });
    patch(XHR, "setRequestHeader", (orig) => function setRequestHeader(name, value) {
      const m = xhrMeta.get(this);
      if (m && String(name).toLowerCase() === "content-type") m.contentType = String(value);
      return orig.call(this, name, value);
    });
    patch(XHR, "abort", (orig) => function abort() {
      const m = xhrMeta.get(this);
      if (m?.pending) {
        m.cancelled = true;
        m.pending = false;
        orig.call(this);
        queueMicrotask(() => fire(this, ["abort", "loadend"]));
        return;
      }
      return orig.call(this);
    });
    patch(XHR, "send", (origSend) => function send(body) {
      const m = xhrMeta.get(this);
      try {
        if (!m || !pipeline.needsGuard(m.url, m.method, body ?? null)) return origSend.call(this, body);
      } catch {
        return origSend.call(this, body);
      }
      m.pending = true;
      pipeline.guard({ url: m.url, method: m.method, body, contentType: m.contentType }).then(
        (out) => {
          if (m.cancelled || xhrMeta.get(this) !== m) return;
          m.pending = false;
          if (out.action === "block") {
            XHR.abort.call(this);
            fire(this, ["error", "loadend"]);
            return;
          }
          origSend.call(this, out.action === "replace" ? out.body : body);
        },
        (e) => {
          if (m.cancelled || xhrMeta.get(this) !== m) return;
          m.pending = false;
          console.warn("[Zuko] guard error, request sent unchanged:", e);
          origSend.call(this, body);
        }
      );
    });
    function fire(xhr, types) {
      for (const t of types) {
        try {
          xhr.dispatchEvent(new win.ProgressEvent(t));
        } catch {
        }
      }
    }
    const wsQueue = /* @__PURE__ */ new WeakMap();
    patch(win.WebSocket?.prototype, "send", (orig) => function send(data) {
      const httpUrl = String(this.url).replace(/^ws/i, "http");
      const q = wsQueue.get(this);
      let need = false;
      try {
        need = (q?.pending ?? 0) > 0 || pipeline.needsGuard(httpUrl, "POST", data);
      } catch {
        need = false;
      }
      if (!need) return orig.call(this, data);
      const state = q ?? { tail: Promise.resolve(), pending: 0 };
      wsQueue.set(this, state);
      state.pending++;
      state.tail = state.tail.then(async () => {
        let out = { action: "pass" };
        try {
          out = await pipeline.guard({ url: httpUrl, method: "POST", body: data });
        } catch (e) {
          console.warn("[Zuko] guard error, message sent unchanged:", e);
        }
        if (out.action === "block") return;
        if (this.readyState !== 1) return;
        orig.call(this, out.action === "replace" ? out.body : data);
      }).catch(() => void 0).finally(() => {
        state.pending--;
      });
    });
    patch(win.Navigator?.prototype, "sendBeacon", (orig) => function sendBeacon(url, data) {
      let need = false;
      try {
        need = pipeline.needsGuard(String(url), "POST", data ?? null);
      } catch {
        need = false;
      }
      if (!need) return orig.call(this, url, data);
      const self = this;
      pipeline.guard({ url: String(url), method: "POST", body: data }).then(
        (out) => {
          if (out.action === "block") return;
          orig.call(self, url, out.action === "replace" ? out.body : data);
        },
        () => void orig.call(self, url, data)
      );
      return true;
    });
    const Clip = win.Clipboard?.prototype;
    patch(Clip, "writeText", (orig) => async function writeText(text) {
      try {
        if (bridge.state.enabled && typeof text === "string" && /\d/.test(text) && bridge.connected()) {
          const r = await bridge.request({ type: "clipboard", items: { "text/plain": text } }, 3e3);
          if (r.written) return;
        }
      } catch {
      }
      return orig.call(this, text);
    });
    patch(Clip, "write", (orig) => async function write(items) {
      try {
        if (bridge.state.enabled && bridge.connected()) {
          const texts = {};
          for (const item of items) {
            for (const type of ["text/plain", "text/html"]) {
              if (item.types.includes(type)) texts[type] = await (await item.getType(type)).text();
            }
          }
          if (Object.keys(texts).length > 0 && Object.values(texts).some((t) => /\d/.test(t))) {
            const r = await bridge.request({ type: "clipboard", items: texts }, 3e3);
            if (r.written) return;
          }
        }
      } catch {
      }
      return orig.call(this, items);
    });
    return {
      pipeline,
      bridge,
      uninstall() {
        undo.reverse().forEach((f) => f());
      }
    };
  }
  function headerOf(headers, name) {
    if (!headers) return null;
    if (typeof headers.get === "function") return headers.get(name);
    if (Array.isArray(headers)) return headers.find(([k]) => k.toLowerCase() === name)?.[1] ?? null;
    const rec = headers;
    const key = Object.keys(rec).find((k) => k.toLowerCase() === name);
    return key ? rec[key] : null;
  }
  function fallbackBanner(win, text) {
    try {
      const doc = win.document;
      const host = doc.createElement("div");
      host.style.cssText = "all:initial;position:fixed;z-index:2147483647;right:16px;bottom:16px;";
      const root = host.attachShadow({ mode: "closed" });
      const box = doc.createElement("div");
      box.textContent = text;
      box.style.cssText = "font:13px/1.4 system-ui,sans-serif;color:#fff;background:#0f1530;border:1px solid #2ee6c5;border-left:4px solid #ff7a1a;border-radius:8px;padding:10px 14px;max-width:360px;box-shadow:0 6px 24px rgba(0,0,0,.4)";
      root.appendChild(box);
      (doc.body ?? doc.documentElement).appendChild(host);
      win.setTimeout(() => host.remove(), 12e3);
    } catch {
    }
  }

  // src/main-world/net-guard.ts
  var w = window;
  var site = siteForHost(w.location.hostname);
  if (site && !w.__zukoNetGuard) {
    Object.defineProperty(w, "__zukoNetGuard", { value: true, enumerable: false });
    installNetGuard(w, site);
  }
})();
